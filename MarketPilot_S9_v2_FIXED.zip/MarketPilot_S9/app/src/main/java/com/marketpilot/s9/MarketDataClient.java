package com.marketpilot.s9;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Twelve Data time-series client. Contains no Android classes so it can be unit-tested on a plain JVM. */
final class MarketDataClient {
    private MarketDataClient() {}

    static final String ENDPOINT = "https://api.twelvedata.com/time_series";
    static final int OUTPUT_SIZE = 1000;
    private static final int MAX_BODY_CHARS = 8_000_000;

    static final class DataException extends Exception {
        private static final long serialVersionUID = 1L;

        enum Kind { AUTH, RATE_LIMIT, NETWORK, SERVER, DATA }

        final Kind kind;

        DataException(Kind kind, String message) {
            super(message);
            this.kind = kind;
        }
    }

    static List<Candle> fetch(String apiKey, Instrument inst, Timeframe tf) throws DataException {
        HttpURLConnection conn = null;
        try {
            String url = ENDPOINT
                    + "?symbol=" + URLEncoder.encode(inst.label, "UTF-8")
                    + "&interval=" + tf.api
                    + "&outputsize=" + OUTPUT_SIZE
                    + "&timezone=UTC&order=DESC"
                    + "&apikey=" + URLEncoder.encode(apiKey, "UTF-8");
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(10_000);
            conn.setReadTimeout(20_000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", "MarketPilot/2.0 (Android)");
            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String body = in == null ? "" : readAll(in);
            if (code >= 400) {
                // Twelve Data normally explains errors in a JSON body; surface that if present,
                // otherwise (e.g. an HTML gateway page) fall back to the HTTP status.
                DataException fromBody = null;
                try {
                    fromBody = errorFrom(new JSONObject(body), apiKey);
                } catch (JSONException | NullPointerException ignored) {
                    // not JSON
                }
                throw fromBody != null ? fromBody : httpError(code);
            }
            return parse(body, apiKey);
        } catch (UnknownHostException e) {
            throw new DataException(DataException.Kind.NETWORK, "No internet connection (cannot reach api.twelvedata.com).");
        } catch (SocketTimeoutException e) {
            throw new DataException(DataException.Kind.NETWORK, "The data provider timed out. Try again in a moment.");
        } catch (IOException e) {
            throw new DataException(DataException.Kind.NETWORK, "Network error: " + redact(String.valueOf(e.getMessage()), apiKey));
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static DataException httpError(int code) {
        if (code == 401 || code == 403) {
            return new DataException(DataException.Kind.AUTH, "The API key was rejected. Check it under API KEY.");
        }
        if (code == 429) {
            return new DataException(DataException.Kind.RATE_LIMIT, rateLimitText());
        }
        if (code >= 500) {
            return new DataException(DataException.Kind.SERVER, "The data provider is having problems (HTTP " + code + ").");
        }
        return new DataException(DataException.Kind.DATA, "Unexpected response (HTTP " + code + ").");
    }

    private static String rateLimitText() {
        return "Rate limit reached (free plan: 8 requests/min, 800/day). Wait a minute, then refresh.";
    }

    private static String readAll(InputStream in) throws IOException, DataException {
        StringBuilder sb = new StringBuilder();
        try (Reader r = new InputStreamReader(in, "UTF-8")) {
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) != -1) {
                sb.append(buf, 0, n);
                if (sb.length() > MAX_BODY_CHARS) {
                    throw new DataException(DataException.Kind.DATA, "Response from the data provider was too large.");
                }
            }
        }
        return sb.toString();
    }

    static String redact(String text, String apiKey) {
        if (text == null) return "";
        String out = text;
        if (apiKey != null && apiKey.length() >= 4) out = out.replace(apiKey, "•••");
        return out.length() > 200 ? out.substring(0, 200) + "…" : out;
    }

    /** Returns the exception described by an API error body, or null if the body is not an error. */
    private static DataException errorFrom(JSONObject root, String apiKey) {
        boolean isError = "error".equalsIgnoreCase(root.optString("status", ""));
        int code = root.optInt("code", 0);
        if (!isError && code < 400) return null;
        String msg = root.optString("message", "API error");
        if (code == 401 || code == 403) {
            return new DataException(DataException.Kind.AUTH, "The API key is missing or invalid. Check it under API KEY.");
        }
        if (code == 429) {
            return new DataException(DataException.Kind.RATE_LIMIT, rateLimitText());
        }
        DataException.Kind kind = code >= 500 ? DataException.Kind.SERVER : DataException.Kind.DATA;
        return new DataException(kind, redact(msg, apiKey));
    }

    /** Parses a Twelve Data time_series body into oldest-first candles. */
    static List<Candle> parse(String body, String apiKey) throws DataException {
        JSONObject root;
        try {
            root = new JSONObject(body);
        } catch (JSONException | NullPointerException e) {
            throw new DataException(DataException.Kind.DATA, "Unexpected response from the data provider.");
        }
        DataException err = errorFrom(root, apiKey);
        if (err != null) throw err;
        JSONArray values = root.optJSONArray("values");
        if (values == null || values.length() == 0) {
            throw new DataException(DataException.Kind.DATA, "No candles were returned for this symbol and timeframe.");
        }
        ArrayList<Candle> out = new ArrayList<>(values.length());
        boolean allTimed = true;
        for (int k = 0; k < values.length(); k++) {
            JSONObject x = values.optJSONObject(k);
            if (x == null) continue;
            try {
                double o = x.getDouble("open"), h = x.getDouble("high"), l = x.getDouble("low"), c = x.getDouble("close");
                if (!Indicators.valid(o) || !Indicators.valid(h) || !Indicators.valid(l) || !Indicators.valid(c)) continue;
                if (o <= 0 || h <= 0 || l <= 0 || c <= 0 || h < l) continue;
                long t = parseTime(x.optString("datetime", ""));
                if (t <= 0) allTimed = false;
                out.add(new Candle(t, o, h, l, c));
            } catch (JSONException e) {
                // skip malformed row
            }
        }
        if (out.isEmpty()) {
            throw new DataException(DataException.Kind.DATA, "The data provider returned no usable candles.");
        }
        if (allTimed) {
            Collections.sort(out, new Comparator<Candle>() {
                @Override public int compare(Candle a, Candle b) { return Long.compare(a.time, b.time); }
            });
            ArrayList<Candle> dedup = new ArrayList<>(out.size());
            long prev = Long.MIN_VALUE;
            for (Candle k : out) {
                if (k.time != prev) dedup.add(k);
                prev = k.time;
            }
            return dedup;
        }
        Collections.reverse(out); // API order is newest-first
        return out;
    }

    static long parseTime(String s) {
        if (s == null || s.length() < 10) return 0;
        try {
            SimpleDateFormat f = new SimpleDateFormat(s.length() > 10 ? "yyyy-MM-dd HH:mm:ss" : "yyyy-MM-dd", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            f.setLenient(false);
            return f.parse(s).getTime();
        } catch (ParseException | RuntimeException e) {
            return 0;
        }
    }
}
