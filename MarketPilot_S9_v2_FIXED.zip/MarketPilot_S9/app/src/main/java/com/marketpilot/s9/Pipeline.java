package com.marketpilot.s9;

import java.util.List;

/** Runs candles through indicators, the strategy, the history check and the explanation text. */
final class Pipeline {
    private Pipeline() {}

    static final int BACKTEST_MAX_HOLD = 48;

    static final class Result {
        Instrument inst;
        Timeframe tf;
        Series series;
        Analysis analysis;
        Describer.Text text;
        SignalEngine.Backtest backtest;
        boolean simulated, forming, closedOnly, stale;
        long lastBarTime, nowMs, fetchedAt;
        int evalIdx;

        long ageMs() { return lastBarTime > 0 ? Math.max(0, nowMs - lastBarTime) : -1; }
    }

    static Result run(List<Candle> candles, Instrument inst, Timeframe tf, boolean simulated,
                      boolean closedOnly, long nowMs, long fetchedAt) {
        Result r = new Result();
        r.inst = inst;
        r.tf = tf;
        r.simulated = simulated;
        r.closedOnly = closedOnly;
        r.nowMs = nowMs;
        r.fetchedAt = fetchedAt;
        Series s = new Series(candles);
        r.series = s;
        if (s.n == 0) {
            r.analysis = new Analysis();
            r.analysis.insufficient = true;
            r.text = Describer.describe(r.analysis, inst);
            r.backtest = new SignalEngine.Backtest();
            return r;
        }
        int last = s.n - 1;
        r.lastBarTime = s.t[last];
        r.forming = r.lastBarTime > 0 && nowMs >= r.lastBarTime && nowMs - r.lastBarTime < tf.ms;
        r.stale = r.lastBarTime > 0 && nowMs - r.lastBarTime > (long) (tf.ms * 2.2);
        r.evalIdx = (closedOnly && r.forming && last >= 1) ? last - 1 : last;
        r.analysis = SignalEngine.evaluate(s, r.evalIdx, s.c[last]);
        r.backtest = SignalEngine.backtest(s, s.n - (r.forming ? 1 : 0), BACKTEST_MAX_HOLD);
        r.text = Describer.describe(r.analysis, inst);
        if (r.forming && !r.analysis.insufficient) {
            r.text.notes.add(0, closedOnly
                    ? "Indicators use the last closed candle; the current one is still forming."
                    : "Indicators include the forming candle — the signal can flip before it closes.");
        }
        return r;
    }
}
