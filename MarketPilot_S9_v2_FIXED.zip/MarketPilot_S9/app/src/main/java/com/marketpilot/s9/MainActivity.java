package com.marketpilot.s9;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MarketPilot: decision-support for forex, gold and silver. It never places trades.
 *
 * Data flow: spinner / button -> refresh() -> (network or simulated candles) on a worker thread ->
 * Pipeline.run() -> present() on the UI thread. Results are keyed by "symbol|timeframe" and ignored if the
 * user has since selected something else, so a slow response can never overwrite a newer selection.
 */
public class MainActivity extends Activity {
    // ---- palette ----
    private static final int BG = 0xFF0A0E17, PANEL = 0xFF111827, TEXT = 0xFFF8FAFC, MUTED = 0xFF94A3B8;
    private static final int ACCENT = 0xFF8B5CF6, GREEN = 0xFF22C55E, RED = 0xFFEF4444, AMBER = 0xFFF59E0B;

    // ---- prefs ----
    private static final String P_SYM = "sym", P_TF = "tf", P_CLOSED = "closed_only", P_BAL = "balance", P_RISK = "risk_pct";

    private static final long CACHE_TTL_MS = 45_000L;
    private static final long RATE_BLOCK_MS = 60_000L;
    private static final int DEMO_CANDLES = 1000;

    private static final class CacheEntry {
        final List<Candle> candles;
        final long at;

        CacheEntry(List<Candle> candles, long at) {
            this.candles = candles;
            this.at = at;
        }
    }

    // Process-wide so a configuration change does not waste API credits. Touched on the UI thread only.
    private static final HashMap<String, CacheEntry> CACHE = new HashMap<>();
    private static long rateBlockedUntil = 0L;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private SecureStore secure;
    private String apiKey = "";
    private int symPos, tfPos;
    private volatile boolean closedOnly = true;
    private double balance = 10000.0, riskPct = 1.0;

    private volatile String wantedKey = "";
    private String inFlightKey = null;
    private String displayedKey = null;
    private Pipeline.Result current = null;

    // ---- views ----
    private LinearLayout root, content, notesCard;
    private TextView statusPill, banner, priceView, badge, headline, metaView, dataView;
    private TextView planTitle, planBody, confTitle, confBody, notesBody, histBody;
    private Spinner symbolSpin, tfSpin;
    private ChartView chart;
    private Button refreshBtn;

    // ======================================================================== lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("mp", MODE_PRIVATE);
        secure = new SecureStore(prefs);
        apiKey = secure.load();
        symPos = clamp(prefs.getInt(P_SYM, 0), Instrument.values().length);
        tfPos = clamp(prefs.getInt(P_TF, 1), Timeframe.values().length);
        closedOnly = prefs.getBoolean(P_CLOSED, true);
        balance = readDouble(P_BAL, 10000.0);
        riskPct = readDouble(P_RISK, 1.0);
        buildUi();
        refresh(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (current != null && !current.simulated && !apiKey.isEmpty()
                && System.currentTimeMillis() - current.fetchedAt > 60_000L) {
            refresh(false);
        }
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    // ======================================================================== small helpers

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static int clamp(int v, int size) {
        return Math.max(0, Math.min(size - 1, v));
    }

    private double readDouble(String key, double def) {
        try {
            double v = Double.parseDouble(prefs.getString(key, Double.toString(def)));
            return (Double.isNaN(v) || Double.isInfinite(v) || v <= 0) ? def : v;
        } catch (RuntimeException e) {
            return def;
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 11, MUTED, true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(round(PANEL, 18));
        return c;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private Button button(String label, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setMinimumHeight(dp(48));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), round(fill, 14), null));
        return b;
    }

    private ArrayAdapter<String> spinnerAdapter(String[] items) {
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(TEXT);
                t.setTextSize(15);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                return t;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setTextColor(TEXT);
                t.setTextSize(15);
                t.setPadding(dp(16), dp(12), dp(16), dp(12));
                return t;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return ad;
    }

    // ======================================================================== UI construction

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            // Android 15+ draws edge-to-edge for apps targeting API 35: keep content clear of system bars.
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        // Top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(12), dp(16), dp(6));
        TextView title = text("MARKETPILOT", 20, TEXT, true);
        title.setLetterSpacing(0.04f);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        statusPill = text("", 11, AMBER, true);
        statusPill.setPadding(dp(10), dp(5), dp(10), dp(5));
        bar.addView(statusPill, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar);

        // Selectors
        LinearLayout sel = new LinearLayout(this);
        sel.setPadding(dp(12), 0, dp(12), dp(4));
        symbolSpin = new Spinner(this);
        symbolSpin.setAdapter(spinnerAdapter(Instrument.labels()));
        symbolSpin.setSelection(symPos);
        sel.addView(symbolSpin, new LinearLayout.LayoutParams(0, dp(48), 1f));
        tfSpin = new Spinner(this);
        tfSpin.setAdapter(spinnerAdapter(Timeframe.displayNames()));
        tfSpin.setSelection(tfPos);
        sel.addView(tfSpin, new LinearLayout.LayoutParams(dp(100), dp(48)));
        root.addView(sel);

        banner = text("", 12, AMBER, false);
        banner.setPadding(dp(12), dp(9), dp(12), dp(9));
        banner.setVisibility(View.GONE);
        root.addView(banner, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 12, 2, 12, 4));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(4), dp(12), dp(20));
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(false);
        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        // Header card
        LinearLayout head = card();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        priceView = text("—", 30, TEXT, true);
        row.addView(priceView, new LinearLayout.LayoutParams(0, WRAP, 1f));
        badge = text("WAIT", 20, AMBER, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(18), dp(8), dp(18), dp(8));
        row.addView(badge, new LinearLayout.LayoutParams(WRAP, WRAP));
        head.addView(row);
        headline = text("Waiting for market data…", 14, TEXT, true);
        headline.setPadding(0, dp(8), 0, 0);
        head.addView(headline);
        metaView = text("", 12, MUTED, false);
        metaView.setPadding(0, dp(4), 0, 0);
        head.addView(metaView);
        dataView = text("", 11, MUTED, false);
        dataView.setPadding(0, dp(4), 0, 0);
        head.addView(dataView);
        content.addView(head, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Chart
        LinearLayout chartCard = card();
        chartCard.setPadding(dp(4), dp(4), dp(4), dp(4));
        chart = new ChartView(this);
        chartCard.addView(chart, new LinearLayout.LayoutParams(MATCH, dp(290)));
        content.addView(chartCard, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Plan
        LinearLayout plan = card();
        planTitle = sectionTitle("TRADE PLAN");
        plan.addView(planTitle);
        planBody = text("", 14, TEXT, false);
        planBody.setTypeface(Typeface.MONOSPACE);
        plan.addView(planBody);
        content.addView(plan, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Confluence
        LinearLayout conf = card();
        confTitle = sectionTitle("CONFLUENCE");
        conf.addView(confTitle);
        confBody = text("", 14, TEXT, false);
        conf.addView(confBody);
        content.addView(conf, lp(MATCH, WRAP, 0, 0, 0, 10));

        // Notes
        notesCard = card();
        notesCard.addView(sectionTitle("WATCH-OUTS"));
        notesBody = text("", 13, 0xFFE2E8F0, false);
        notesCard.addView(notesBody);
        content.addView(notesCard, lp(MATCH, WRAP, 0, 0, 0, 10));

        // History check
        LinearLayout hist = card();
        hist.addView(sectionTitle("RULE CHECK ON LOADED HISTORY"));
        histBody = text("", 13, 0xFFE2E8F0, false);
        hist.addView(histBody);
        content.addView(hist, lp(MATCH, WRAP, 0, 0, 0, 12));

        // Buttons
        refreshBtn = button("REFRESH & ANALYZE", ACCENT, TEXT);
        refreshBtn.setOnClickListener(v -> refresh(true));
        content.addView(refreshBtn, lp(MATCH, dp(52), 0, 0, 0, 8));

        LinearLayout row2 = new LinearLayout(this);
        Button keyBtn = button("API KEY", PANEL, TEXT);
        keyBtn.setOnClickListener(v -> showKeyDialog());
        LinearLayout.LayoutParams keyLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        keyLp.setMargins(0, 0, dp(4), 0);
        row2.addView(keyBtn, keyLp);
        Button riskBtn = button("POSITION SIZING", PANEL, TEXT);
        riskBtn.setOnClickListener(v -> showRiskDialog());
        LinearLayout.LayoutParams riskLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        riskLp.setMargins(dp(4), 0, 0, 0);
        row2.addView(riskBtn, riskLp);
        content.addView(row2, lp(MATCH, WRAP, 0, 0, 0, 8));

        Switch closedSwitch = new Switch(this);
        closedSwitch.setText("Closed candles only (no repainting)");
        closedSwitch.setTextColor(TEXT);
        closedSwitch.setTextSize(13);
        closedSwitch.setChecked(closedOnly);
        closedSwitch.setPadding(dp(4), dp(8), dp(4), dp(8));
        closedSwitch.setOnCheckedChangeListener((b, checked) -> {
            closedOnly = checked;
            prefs.edit().putBoolean(P_CLOSED, checked).apply();
            recomputeFromCache();
        });
        content.addView(closedSwitch, lp(MATCH, WRAP, 0, 0, 0, 4));

        TextView note = text("Decision-support only. No signal is guaranteed and the score is a confluence count, not a probability. "
                + "Verify price, spread, session and risk before trading. MarketPilot never places orders.", 11, MUTED, false);
        note.setPadding(dp(4), dp(4), dp(4), 0);
        content.addView(note);

        symbolSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (pos == symPos) return; // initial layout callback or no change
                symPos = pos;
                prefs.edit().putInt(P_SYM, pos).apply();
                refresh(false);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        tfSpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (pos == tfPos) return;
                tfPos = pos;
                prefs.edit().putInt(P_TF, pos).apply();
                refresh(false);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        showLoading();
        setContentView(root);
    }

    // ======================================================================== data flow

    private String selectionKey() {
        return Instrument.at(symPos).label + "|" + Timeframe.at(tfPos).api;
    }

    /** Entry point for every spinner change, button tap and resume. Network is only touched when needed. */
    private void refresh(boolean force) {
        final Instrument inst = Instrument.at(symPos);
        final Timeframe tf = Timeframe.at(tfPos);
        final String ck = selectionKey();
        wantedKey = ck;
        if (!ck.equals(displayedKey)) showLoading();

        if (apiKey.isEmpty()) {
            compute(null, inst, tf, true, ck, System.currentTimeMillis(), null);
            return;
        }
        final long now = System.currentTimeMillis();
        final CacheEntry ce = CACHE.get(ck);
        if (!force && ce != null && now - ce.at < CACHE_TTL_MS) {
            compute(ce.candles, inst, tf, false, ck, ce.at, null);
            return;
        }
        if (now < rateBlockedUntil) {
            String wait = "Rate limit protection: next request allowed in " + ((rateBlockedUntil - now + 999) / 1000) + "s.";
            if (ce != null) compute(ce.candles, inst, tf, false, ck, ce.at, wait);
            else showNoData(wait);
            return;
        }
        if (ck.equals(inFlightKey)) return;
        inFlightKey = ck;
        setStatus("LOADING…", MUTED);
        final String key = apiKey;
        worker.execute(() -> {
            if (!ck.equals(wantedKey)) { // user already moved on: do not waste an API credit
                runOnUiThread(() -> { if (ck.equals(inFlightKey)) inFlightKey = null; });
                return;
            }
            try {
                final List<Candle> list = MarketDataClient.fetch(key, inst, tf);
                final long at = System.currentTimeMillis();
                final Pipeline.Result res = Pipeline.run(list, inst, tf, false, closedOnly, at, at);
                runOnUiThread(() -> onFetched(ck, list, at, res));
            } catch (MarketDataClient.DataException e) {
                runOnUiThread(() -> onFetchFailed(ck, e.kind, e.getMessage()));
            } catch (RuntimeException e) {
                runOnUiThread(() -> onFetchFailed(ck, MarketDataClient.DataException.Kind.DATA,
                        "Unexpected error while loading data (" + e.getClass().getSimpleName() + ")."));
            }
        });
    }

    private void onFetched(String ck, List<Candle> list, long at, Pipeline.Result res) {
        if (isDestroyed()) return;
        if (ck.equals(inFlightKey)) inFlightKey = null;
        CACHE.put(ck, new CacheEntry(list, at));
        if (ck.equals(wantedKey)) present(res, null);
    }

    private void onFetchFailed(String ck, MarketDataClient.DataException.Kind kind, String message) {
        if (isDestroyed()) return;
        if (ck.equals(inFlightKey)) inFlightKey = null;
        if (kind == MarketDataClient.DataException.Kind.RATE_LIMIT) {
            rateBlockedUntil = System.currentTimeMillis() + RATE_BLOCK_MS;
        }
        if (!ck.equals(wantedKey)) return;
        CacheEntry ce = CACHE.get(ck);
        if (ce != null) {
            compute(ce.candles, Instrument.at(symPos), Timeframe.at(tfPos), false, ck, ce.at, message);
        } else {
            showNoData(message);
        }
    }

    /** Runs the analysis on the worker thread (cheap, but keeps the UI thread free) and presents the result. */
    private void compute(final List<Candle> candlesOrNull, final Instrument inst, final Timeframe tf,
                         final boolean simulated, final String ck, final long fetchedAt, final String errorNote) {
        final boolean closed = closedOnly;
        try {
            worker.execute(() -> {
                try {
                    long now = System.currentTimeMillis();
                    List<Candle> list = simulated ? DemoData.generate(inst, tf, DEMO_CANDLES, now) : candlesOrNull;
                    final Pipeline.Result res = Pipeline.run(list, inst, tf, simulated, closed, now, fetchedAt);
                    runOnUiThread(() -> {
                        if (!isDestroyed() && ck.equals(wantedKey)) present(res, errorNote);
                    });
                } catch (RuntimeException e) {
                    runOnUiThread(() -> {
                        if (!isDestroyed() && ck.equals(wantedKey)) {
                            showNoData("Analysis failed (" + e.getClass().getSimpleName() + ").");
                        }
                    });
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            // activity is shutting down
        }
    }

    private void recomputeFromCache() {
        final Instrument inst = Instrument.at(symPos);
        final Timeframe tf = Timeframe.at(tfPos);
        final String ck = selectionKey();
        wantedKey = ck;
        if (apiKey.isEmpty()) {
            compute(null, inst, tf, true, ck, System.currentTimeMillis(), null);
            return;
        }
        CacheEntry ce = CACHE.get(ck);
        if (ce != null) compute(ce.candles, inst, tf, false, ck, ce.at, null);
        else refresh(false);
    }

    // ======================================================================== presentation

    private void setStatus(String label, int color) {
        statusPill.setText(label);
        statusPill.setTextColor(color);
        statusPill.setBackground(round(withAlpha(color, 0x26), 12));
    }

    private void showBanner(String msg, int color) {
        banner.setText(msg);
        banner.setTextColor(color);
        banner.setBackground(round(withAlpha(color, 0x1F), 12));
        banner.setVisibility(View.VISIBLE);
    }

    private void hideBanner() {
        banner.setVisibility(View.GONE);
    }

    private void showLoading() {
        displayedKey = null;
        current = null;
        priceView.setText("—");
        setBadge("…", MUTED);
        headline.setText("Loading " + Instrument.at(symPos).label + " " + Timeframe.at(tfPos).display + "…");
        metaView.setText("");
        dataView.setText("");
        chart.clear("Loading…");
        planTitle.setText("TRADE PLAN");
        planBody.setText("");
        confTitle.setText("CONFLUENCE");
        confBody.setText("");
        notesCard.setVisibility(View.GONE);
        histBody.setText("");
        setStatus("LOADING…", MUTED);
    }

    /** Shown when there is genuinely nothing to analyse. We never substitute fake data for a failed request. */
    private void showNoData(String message) {
        displayedKey = null;
        current = null;
        priceView.setText("—");
        setBadge("NO DATA", MUTED);
        headline.setText("No market data loaded");
        metaView.setText("");
        dataView.setText(Instrument.at(symPos).label + "  ·  " + Timeframe.at(tfPos).display);
        chart.clear("No data");
        planTitle.setText("TRADE PLAN");
        planBody.setText("Nothing to analyse. No signal is shown without real data.");
        confTitle.setText("CONFLUENCE");
        confBody.setText("");
        notesCard.setVisibility(View.GONE);
        histBody.setText("");
        setStatus("ERROR", RED);
        showBanner(message + " Tap REFRESH to retry.", RED);
    }

    private void setBadge(String label, int color) {
        badge.setText(label);
        badge.setTextColor(color);
        GradientDrawable g = round(withAlpha(color, 0x2E), 14);
        g.setStroke(dp(1), withAlpha(color, 0x80));
        badge.setBackground(g);
    }

    private void present(Pipeline.Result r, String errorNote) {
        render(r);
        if (errorNote != null) {
            setStatus("STALE", AMBER);
            showBanner(errorNote + " Showing the last data received" + ageSuffix(r) + ".", errorNote.startsWith("Rate limit") ? AMBER : RED);
        } else if (r.simulated) {
            setStatus("SIMULATED", AMBER);
            showBanner("Simulated data, not real prices. Add a Twelve Data API key to analyse live markets.", AMBER);
        } else if (r.stale) {
            setStatus("LIVE", GREEN);
            showBanner("The market may be closed or the feed delayed. The latest candle opened " + ageText(r.ageMs()) + ".", AMBER);
        } else {
            setStatus("LIVE", GREEN);
            hideBanner();
        }
    }

    private String ageSuffix(Pipeline.Result r) {
        long age = System.currentTimeMillis() - r.fetchedAt;
        return age > 60_000L ? " (" + ageText(age) + ")" : "";
    }

    private void render(Pipeline.Result r) {
        current = r;
        displayedKey = r.inst.label + "|" + r.tf.api;
        final Instrument inst = r.inst;
        final Analysis a = r.analysis;
        final Series s = r.series;
        final Describer.Text t = r.text;

        if (s.n > 0) priceView.setText(inst.format(s.c[s.n - 1]));
        else priceView.setText("—");

        if (a.insufficient) {
            setBadge("WAIT", MUTED);
        } else if (a.signal == Analysis.Signal.BUY) {
            setBadge("BUY", GREEN);
        } else if (a.signal == Analysis.Signal.SELL) {
            setBadge("SELL", RED);
        } else {
            setBadge("WAIT", AMBER);
        }
        headline.setText(t.headline);
        metaView.setText(t.meta);
        String when = r.lastBarTime > 0
                ? "  ·  candle " + formatTime(r.lastBarTime, r.tf) + " UTC (" + ageText(r.ageMs()) + ")" : "";
        dataView.setText(inst.label + "  ·  " + r.tf.display + when + "  ·  "
                + (r.closedOnly ? "closed candles" : "incl. forming candle") + "  ·  " + s.n + " bars");

        chart.setData(s, a, inst, r.simulated);
        renderPlan(inst, a);
        renderConfluence(a, t);

        if (t.notes.isEmpty()) {
            notesCard.setVisibility(View.GONE);
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < t.notes.size(); i++) {
                if (i > 0) sb.append("\n\n");
                sb.append("•  ").append(t.notes.get(i));
            }
            notesBody.setText(sb.toString());
            notesCard.setVisibility(View.VISIBLE);
        }
        renderHistory(r);
    }

    private static String row(String label, String value) {
        return String.format(Locale.US, "%-9s%s", label, value);
    }

    private void renderPlan(Instrument inst, Analysis a) {
        if (a.insufficient) {
            planTitle.setText("TRADE PLAN");
            planBody.setText("Waiting for enough candles.");
            return;
        }
        if (a.isTrade()) {
            boolean buy = a.signal == Analysis.Signal.BUY;
            planTitle.setText("TRADE PLAN  ·  " + (buy ? "LONG" : "SHORT"));
            StringBuilder sb = new StringBuilder();
            sb.append(row("ENTRY", inst.format(a.entry) + "  (market)")).append('\n');
            sb.append(row("STOP", inst.format(a.sl) + "  -" + inst.formatDistance(a.risk))).append('\n');
            sb.append(row("TP1", inst.format(a.tp1) + "  +" + inst.formatDistance(a.risk * a.rr1) + "  " + trim(a.rr1) + "R")).append('\n');
            sb.append(row("TP2", inst.format(a.tp2) + "  +" + inst.formatDistance(a.risk * a.rr2) + "  " + trim(a.rr2) + "R")).append('\n');
            double lots = RiskCalculator.lots(inst, balance, riskPct, a.entry, a.sl);
            if (lots >= 0.01) {
                double loss = RiskCalculator.lossAtStop(inst, lots, a.entry, a.sl);
                sb.append(row("SIZE", String.format(Locale.US, "%.2f lots", lots))).append('\n');
                sb.append(String.format(Locale.US, "         risks ≈ $%.2f (%.1f%% of $%,.0f)", loss, riskPct, balance));
            } else {
                sb.append(row("SIZE", "< 0.01 lot")).append('\n');
                sb.append("         stop is too wide for this risk budget");
            }
            planBody.setText(sb.toString());
        } else {
            planTitle.setText("NO TRADE SETUP  ·  KEY LEVELS");
            StringBuilder sb = new StringBuilder();
            sb.append(row("RESIST", Double.isNaN(a.resistance) ? "—" : inst.format(a.resistance))).append('\n');
            sb.append(row("SUPPORT", Double.isNaN(a.support) ? "—" : inst.format(a.support))).append("\n\n");
            if (!Double.isNaN(a.resistance)) sb.append("Bullish trigger: close above ").append(inst.format(a.resistance)).append('\n');
            if (!Double.isNaN(a.support)) sb.append("Bearish trigger: close below ").append(inst.format(a.support));
            planBody.setText(sb.toString().trim());
        }
    }

    private static String trim(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
    }

    private void renderConfluence(Analysis a, Describer.Text t) {
        if (a.insufficient) {
            confTitle.setText("CONFLUENCE");
            confBody.setText("—");
            return;
        }
        confTitle.setText("CONFLUENCE  " + Describer.signed(a.score) + " / " + SignalEngine.MAX_SCORE
                + "   (signal needs ±" + SignalEngine.SCORE_THRESHOLD + ")");
        SpannableStringBuilder sb = new SpannableStringBuilder();
        appendRow(sb, "Trend", a.trend, t.trend);
        appendRow(sb, "Momentum", a.momentum, t.momentum);
        appendRow(sb, "Volatility", a.volatility, t.volatility);
        appendRow(sb, "Structure", a.structure, t.structure);
        while (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\n') sb.delete(sb.length() - 1, sb.length());
        confBody.setText(sb);
    }

    private void appendRow(SpannableStringBuilder sb, String name, int score, String why) {
        int start = sb.length();
        sb.append(name);
        sb.setSpan(new StyleSpan(Typeface.BOLD), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int scoreStart = sb.length();
        sb.append("   ").append(Describer.signed(score));
        sb.setSpan(new StyleSpan(Typeface.BOLD), scoreStart, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan(score > 0 ? GREEN : (score < 0 ? RED : MUTED)),
                scoreStart, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.append('\n');
        int whyStart = sb.length();
        sb.append(why).append("\n\n");
        sb.setSpan(new ForegroundColorSpan(MUTED), whyStart, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new RelativeSizeSpan(0.85f), whyStart, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void renderHistory(Pipeline.Result r) {
        SignalEngine.Backtest b = r.backtest;
        StringBuilder sb = new StringBuilder();
        if (b.trades == 0) {
            sb.append("No completed signals in the ").append(r.series.n).append(" loaded candles.");
        } else {
            sb.append(String.format(Locale.US, "%d signals replayed on %d candles%n", b.trades, r.series.n));
            sb.append(String.format(Locale.US, "TP1 first: %d (%.0f%%)  ·  stopped: %d  ·  timed out: %d%n",
                    b.wins, b.winRate() * 100.0, b.losses, b.timeouts));
            sb.append(String.format(Locale.US, "Average result: %+.2f R (R = amount risked per trade)", b.avgR()));
        }
        sb.append("\n\nThis replays the same rules on past data, ignoring spread and slippage. ")
          .append("It is not a forecast")
          .append(b.trades < 15 ? " and the sample is small." : ".");
        if (r.simulated) sb.append(" On simulated data these numbers mean nothing.");
        histBody.setText(sb.toString());
    }

    private static String formatTime(long ms, Timeframe tf) {
        SimpleDateFormat f = new SimpleDateFormat(tf == Timeframe.D1 ? "MMM d" : "MMM d HH:mm", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date(ms));
    }

    private static String ageText(long ms) {
        if (ms < 0) return "";
        long m = ms / 60_000L;
        if (m < 1) return "just now";
        if (m < 60) return m + "m ago";
        long h = m / 60;
        if (h < 48) return h + "h ago";
        return (h / 24) + "d ago";
    }

    // ======================================================================== dialogs

    private void showKeyDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), 0);

        final EditText input = new EditText(this);
        input.setHint("Paste Twelve Data API key");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setTransformationMethod(PasswordTransformationMethod.getInstance());
        input.setText(apiKey);
        input.setSelection(input.getText().length());
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        CheckBox show = new CheckBox(this);
        show.setText("Show key");
        show.setOnCheckedChangeListener((b, checked) -> {
            input.setTransformationMethod(checked ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            input.setSelection(input.getText().length());
        });
        box.addView(show);

        TextView info = text("Get a free key at twelvedata.com. It is stored encrypted on this device and sent only to "
                + "api.twelvedata.com over HTTPS. Free plans allow 8 requests/min and 800/day; MarketPilot caches results to stay within that.",
                12, MUTED, false);
        info.setPadding(0, dp(8), 0, dp(4));
        box.addView(info);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Live market data")
                .setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    apiKey = input.getText().toString().trim();
                    secure.save(apiKey);
                    CACHE.clear();
                    rateBlockedUntil = 0L;
                    refresh(true);
                })
                .setNegativeButton("CANCEL", null);
        if (!apiKey.isEmpty()) {
            builder.setNeutralButton("REMOVE KEY", (d, w) -> {
                apiKey = "";
                secure.clear();
                CACHE.clear();
                refresh(true);
            });
        }
        builder.show();
    }

    private void showRiskDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), 0);

        box.addView(text("Account balance (USD)", 12, MUTED, false));
        final EditText bal = new EditText(this);
        bal.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        bal.setText(trim(balance));
        box.addView(bal);

        TextView l2 = text("Risk per trade (% of balance)", 12, MUTED, false);
        l2.setPadding(0, dp(10), 0, 0);
        box.addView(l2);
        final EditText risk = new EditText(this);
        risk.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        risk.setText(trim(riskPct));
        box.addView(risk);

        TextView info = text("Lot size is estimated for a USD account with standard contracts (100k units per FX lot, "
                + "100 oz gold, 5,000 oz silver). Your broker's specifications may differ.", 12, MUTED, false);
        info.setPadding(0, dp(10), 0, dp(4));
        box.addView(info);

        new AlertDialog.Builder(this)
                .setTitle("Position sizing")
                .setView(box)
                .setPositiveButton("SAVE", (d, w) -> {
                    try {
                        double nb = Double.parseDouble(bal.getText().toString().trim().replace(',', '.'));
                        double nr = Double.parseDouble(risk.getText().toString().trim().replace(',', '.'));
                        if (!(nb >= 1) || nb > 1e9 || !(nr >= 0.05) || nr > 10) {
                            Toast.makeText(this, "Balance must be ≥ 1 and risk between 0.05% and 10%.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        balance = nb;
                        riskPct = nr;
                        prefs.edit().putString(P_BAL, Double.toString(nb)).putString(P_RISK, Double.toString(nr)).apply();
                        if (current != null) render(current);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Please enter valid numbers.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }
}
