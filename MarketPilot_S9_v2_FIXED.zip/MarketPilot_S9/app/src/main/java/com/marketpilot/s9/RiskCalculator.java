package com.marketpilot.s9;

/**
 * Position sizing for a USD-denominated account using standard contract sizes
 * (100k units per FX lot, 100 oz gold, 5,000 oz silver). Brokers differ, so treat the result as an estimate.
 */
final class RiskCalculator {
    private RiskCalculator() {}

    /** Lots to trade so that hitting the stop loses {@code riskPercent}% of {@code balance}. Rounded down to 0.01. */
    static double lots(Instrument inst, double balance, double riskPercent, double entry, double stop) {
        double dist = Math.abs(entry - stop);
        if (!(dist > 0) || !(balance > 0) || !(riskPercent > 0) || !(entry > 0)) return 0;
        double perLot = dist * inst.usdPerPriceUnit(entry);
        if (!(perLot > 0)) return 0;
        double lots = (balance * riskPercent / 100.0) / perLot;
        return Math.floor(lots * 100.0 + 1e-9) / 100.0;
    }

    /** USD lost if the stop is hit with the given lot size. */
    static double lossAtStop(Instrument inst, double lots, double entry, double stop) {
        return lots * Math.abs(entry - stop) * inst.usdPerPriceUnit(entry);
    }
}
