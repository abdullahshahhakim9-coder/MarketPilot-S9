package com.marketpilot.s9;

/** Result of evaluating the strategy on one bar. Plain data holder. */
final class Analysis {
    enum Signal { BUY, SELL, WAIT }

    Signal signal = Signal.WAIT;
    /** Direction implied by the score alone, before the safety gates (null when |score| is below threshold). */
    Signal candidate = null;
    boolean insufficient;

    int barIndex;
    /** Latest traded price (may be newer than the bar the indicators were computed on). */
    double price = Double.NaN;
    /** Close of the bar the indicators were computed on. */
    double close = Double.NaN;

    int score, trend, momentum, volatility, structure;
    int structureTrend; // +1 HH/HL, -1 LH/LL, 0 mixed or unknown
    boolean hasEma200;

    double ema20 = Double.NaN, ema50 = Double.NaN, ema200 = Double.NaN;
    double rsi = Double.NaN, atr = Double.NaN, adx = Double.NaN, macdHist = Double.NaN, pctB = Double.NaN;
    String regime = "";

    boolean squeeze, brokeUp, brokeDown, rsiStretched, stopCapped;
    boolean blockedScore, blockedTrend, blockedRsi, blockedRegime;

    double support = Double.NaN, resistance = Double.NaN;
    double lastSwingHigh = Double.NaN, lastSwingLow = Double.NaN;
    /** Opposing level sitting between entry and TP1, if any. */
    double obstacle = Double.NaN;

    double entry = Double.NaN, sl = Double.NaN, tp1 = Double.NaN, tp2 = Double.NaN;
    double risk = Double.NaN, rr1 = Double.NaN, rr2 = Double.NaN;

    boolean isTrade() {
        return signal != Signal.WAIT;
    }
}
