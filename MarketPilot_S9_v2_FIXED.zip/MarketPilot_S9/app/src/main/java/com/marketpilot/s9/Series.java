package com.marketpilot.s9;

import java.util.List;

/** A candle history plus every indicator the engine needs, computed once. */
final class Series {
    static final int SWING = 4;

    final int n;
    final long[] t;
    final double[] o, h, l, c;
    final double[] ema20, ema50, ema200, rsi, atr, adx, pdi, mdi;
    final double[] macd, macdSignal, macdHist;
    final double[] bbMid, bbUp, bbLo, bbWidth;
    final int[] swingHighs, swingLows;
    /** Index of the first bar with a valid EMA200, or -1 when there is not enough history. */
    final int firstEma200;

    Series(List<Candle> candles) {
        n = candles.size();
        t = new long[n];
        o = new double[n];
        h = new double[n];
        l = new double[n];
        c = new double[n];
        for (int i = 0; i < n; i++) {
            Candle k = candles.get(i);
            t[i] = k.time;
            o[i] = k.open;
            h[i] = k.high;
            l[i] = k.low;
            c[i] = k.close;
        }
        ema20 = Indicators.ema(c, 20);
        ema50 = Indicators.ema(c, 50);
        ema200 = Indicators.ema(c, 200);
        rsi = Indicators.rsi(c, 14);
        atr = Indicators.atr(h, l, c, 14);
        double[][] ad = Indicators.adx(h, l, c, 14);
        adx = ad[0];
        pdi = ad[1];
        mdi = ad[2];
        double[][] m = Indicators.macd(c, 12, 26, 9);
        macd = m[0];
        macdSignal = m[1];
        macdHist = m[2];
        double[][] b = Indicators.bollinger(c, 20, 2.0);
        bbMid = b[0];
        bbUp = b[1];
        bbLo = b[2];
        bbWidth = Indicators.nanArray(n);
        for (int i = 0; i < n; i++) {
            if (Indicators.valid(bbMid[i]) && bbMid[i] != 0) bbWidth[i] = (bbUp[i] - bbLo[i]) / Math.abs(bbMid[i]);
        }
        swingHighs = Indicators.swingHighs(h, SWING, SWING);
        swingLows = Indicators.swingLows(l, SWING, SWING);
        int f = -1;
        for (int i = 0; i < n; i++) {
            if (Indicators.valid(ema200[i])) { f = i; break; }
        }
        firstEma200 = f;
    }
}
