package com.marketpilot.s9;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Deterministic simulated candles with trending and ranging regimes. Never real market data. */
final class DemoData {
    private DemoData() {}

    static List<Candle> generate(Instrument inst, Timeframe tf, int count, long nowMs) {
        Random r = new Random(1000L * inst.ordinal() + 17L * tf.ordinal() + 7L);
        double sigma = inst.demoDailyVol * Math.sqrt(tf.ms / 86_400_000.0);
        long lastStart = (nowMs / tf.ms) * tf.ms;
        ArrayList<Candle> out = new ArrayList<>(count);
        double p = inst.demoPrice;
        int regimeLeft = 0;
        double drift = 0;
        for (int k = 0; k < count; k++) {
            if (regimeLeft <= 0) {
                regimeLeft = 40 + r.nextInt(80);
                int d = r.nextInt(3);
                drift = (d == 0 ? 0.12 : (d == 1 ? -0.12 : 0.0)) * sigma;
            }
            regimeLeft--;
            double open = p;
            // Gentle pull toward the base price keeps long simulated histories plausible.
            double z = Math.log(open / inst.demoPrice) / (inst.demoDailyVol * 12.0);
            double close = open * Math.exp(drift - 0.1 * sigma * z + sigma * r.nextGaussian());
            double hi = Math.max(open, close) * (1 + Math.abs(r.nextGaussian()) * sigma * 0.3);
            double lo = Math.min(open, close) * (1 - Math.abs(r.nextGaussian()) * sigma * 0.3);
            long time = lastStart - (long) (count - 1 - k) * tf.ms;
            out.add(new Candle(time, open, hi, lo, close));
            p = close;
        }
        return out;
    }
}
