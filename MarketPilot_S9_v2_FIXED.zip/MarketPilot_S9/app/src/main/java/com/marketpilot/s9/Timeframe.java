package com.marketpilot.s9;

/** Supported chart timeframes. {@code api} is the Twelve Data interval string. */
enum Timeframe {
    M15("M15", "15min", 15L * 60_000L),
    H1("H1", "1h", 60L * 60_000L),
    H4("H4", "4h", 4L * 60L * 60_000L),
    D1("D1", "1day", 24L * 60L * 60_000L);

    final String display;
    final String api;
    final long ms;

    Timeframe(String display, String api, long ms) {
        this.display = display;
        this.api = api;
        this.ms = ms;
    }

    static Timeframe at(int index) {
        Timeframe[] all = values();
        return all[Math.max(0, Math.min(all.length - 1, index))];
    }

    static String[] displayNames() {
        Timeframe[] all = values();
        String[] out = new String[all.length];
        for (int i = 0; i < all.length; i++) out[i] = all[i].display;
        return out;
    }
}
