package com.marketpilot.s9;

/**
 * Confluence strategy. Four components are scored, then safety gates decide whether the score may
 * become a BUY/SELL. The score is a confluence count, NOT a probability.
 *
 *   Trend       -3..+3  price vs EMA20, EMA20 vs EMA50, EMA50 vs EMA200
 *   Momentum    -2..+2  RSI(14) zone, MACD(12,26,9) histogram sign
 *   Volatility  -1..+1  Bollinger(20,2) stretch (contrarian, ignored when ADX shows a strong trend)
 *   Structure   -2..+2  swing structure (HH+HL / LH+LL) and break of the last swing
 *
 * A signal needs |score| >= 5 AND: trend agrees (|trend| >= 2), ADX >= 18 (not ranging) and RSI not
 * at an extreme (>= 80 for buys, <= 20 for sells).
 */
final class SignalEngine {
    private SignalEngine() {}

    static final int MIN_BARS = 60;
    static final int SCORE_THRESHOLD = 5;
    static final int MAX_SCORE = 8;

    static final double ADX_RANGING = 18.0;
    static final double ADX_STRONG = 25.0;
    static final double RSI_BULL = 55.0, RSI_BEAR = 45.0;
    static final double RSI_STRETCH_HI = 70.0, RSI_STRETCH_LO = 30.0;
    static final double RSI_EXHAUST_HI = 80.0, RSI_EXHAUST_LO = 20.0;

    static final double SL_DEFAULT_ATR = 1.5, SL_MIN_ATR = 1.0, SL_MAX_ATR = 3.0, SWING_BUFFER_ATR = 0.25;
    static final double TP1_R = 1.5, TP2_R = 2.5;
    static final int LEVEL_LOOKBACK = 250;
    static final int SQUEEZE_LOOKBACK = 100;

    private static int cmp(double a, double b) {
        return a > b ? 1 : (a < b ? -1 : 0);
    }

    private static boolean bad(double v) {
        return !Indicators.valid(v);
    }

    /** Evaluate the strategy using indicator values at bar {@code i}; {@code livePrice} is used for entry/levels. */
    static Analysis evaluate(Series s, int i, double livePrice) {
        Analysis a = new Analysis();
        a.barIndex = i;
        a.price = livePrice;
        if (i < MIN_BARS - 1 || i >= s.n) {
            a.insufficient = true;
            return a;
        }
        final double c = s.c[i];
        a.close = c;
        a.ema20 = s.ema20[i];
        a.ema50 = s.ema50[i];
        a.ema200 = s.ema200[i];
        a.rsi = s.rsi[i];
        a.atr = s.atr[i];
        a.adx = s.adx[i];
        a.macdHist = s.macdHist[i];
        final double up = s.bbUp[i], lo = s.bbLo[i];
        if (bad(a.ema20) || bad(a.ema50) || bad(a.rsi) || bad(a.atr) || bad(a.adx) || bad(a.macdHist)
                || bad(up) || bad(lo) || !(a.atr > 0) || bad(livePrice) || livePrice <= 0) {
            a.insufficient = true;
            return a;
        }
        a.hasEma200 = !bad(a.ema200);
        a.regime = a.adx >= ADX_STRONG ? "TRENDING" : (a.adx >= ADX_RANGING ? "WEAK TREND" : "RANGING");

        // ---- Trend ----
        a.trend = cmp(c, a.ema20) + cmp(a.ema20, a.ema50) + (a.hasEma200 ? cmp(a.ema50, a.ema200) : 0);

        // ---- Momentum ----
        a.momentum = (a.rsi > RSI_BULL ? 1 : (a.rsi < RSI_BEAR ? -1 : 0)) + cmp(a.macdHist, 0);

        // ---- Volatility / Bollinger ----
        double width = up - lo;
        a.pctB = width > 0 ? (c - lo) / width : 0.5;
        a.volatility = 0;
        if (a.adx < ADX_STRONG) {
            if (a.pctB > 1.0) a.volatility = -1;
            else if (a.pctB < 0.0) a.volatility = 1;
        }
        a.squeeze = isSqueeze(s, i);

        // ---- Structure ----
        int lastH = -1, prevH = -1, lastL = -1, prevL = -1;
        for (int k = s.swingHighs.length - 1; k >= 0; k--) {
            int idx = s.swingHighs[k];
            if (idx > i - Series.SWING) continue;
            if (lastH < 0) lastH = idx; else { prevH = idx; break; }
        }
        for (int k = s.swingLows.length - 1; k >= 0; k--) {
            int idx = s.swingLows[k];
            if (idx > i - Series.SWING) continue;
            if (lastL < 0) lastL = idx; else { prevL = idx; break; }
        }
        int st = 0;
        if (lastH >= 0 && prevH >= 0 && lastL >= 0 && prevL >= 0) {
            boolean hh = s.h[lastH] > s.h[prevH], hl = s.l[lastL] > s.l[prevL];
            boolean lh = s.h[lastH] < s.h[prevH], ll = s.l[lastL] < s.l[prevL];
            if (hh && hl) { st += 1; a.structureTrend = 1; }
            else if (lh && ll) { st -= 1; a.structureTrend = -1; }
        }
        if (lastH >= 0) a.lastSwingHigh = s.h[lastH];
        if (lastL >= 0) a.lastSwingLow = s.l[lastL];
        if (lastH >= 0 && c > s.h[lastH]) { st += 1; a.brokeUp = true; }
        else if (lastL >= 0 && c < s.l[lastL]) { st -= 1; a.brokeDown = true; }
        a.structure = st;

        a.score = a.trend + a.momentum + a.volatility + a.structure;

        // ---- Nearest support / resistance around the live price (confirmed swings only) ----
        double res = Double.NaN, sup = Double.NaN;
        for (int k = s.swingHighs.length - 1; k >= 0; k--) {
            int idx = s.swingHighs[k];
            if (idx > i - Series.SWING) continue;
            if (idx < i - LEVEL_LOOKBACK) break;
            double v = s.h[idx];
            if (v > livePrice && (bad(res) || v < res)) res = v;
        }
        for (int k = s.swingLows.length - 1; k >= 0; k--) {
            int idx = s.swingLows[k];
            if (idx > i - Series.SWING) continue;
            if (idx < i - LEVEL_LOOKBACK) break;
            double v = s.l[idx];
            if (v < livePrice && (bad(sup) || v > sup)) sup = v;
        }
        a.resistance = res;
        a.support = sup;

        // ---- Decision + safety gates ----
        boolean wantBuy = a.score >= SCORE_THRESHOLD;
        boolean wantSell = a.score <= -SCORE_THRESHOLD;
        if (!wantBuy && !wantSell) {
            a.blockedScore = true;
            return a;
        }
        a.candidate = wantBuy ? Analysis.Signal.BUY : Analysis.Signal.SELL;
        if (a.adx < ADX_RANGING) a.blockedRegime = true;
        if (wantBuy ? a.trend < 2 : a.trend > -2) a.blockedTrend = true;
        if (wantBuy ? a.rsi >= RSI_EXHAUST_HI : a.rsi <= RSI_EXHAUST_LO) a.blockedRsi = true;
        if (a.blockedRegime || a.blockedTrend || a.blockedRsi) return a;

        a.signal = a.candidate;
        a.rsiStretched = wantBuy ? a.rsi >= RSI_STRETCH_HI : a.rsi <= RSI_STRETCH_LO;

        // ---- Trade levels ----
        final double dir = wantBuy ? 1.0 : -1.0;
        final double entry = livePrice;
        double risk = SL_DEFAULT_ATR * a.atr;
        final double anchor = wantBuy ? sup : res;
        if (!bad(anchor)) {
            double structDist = wantBuy ? entry - (anchor - SWING_BUFFER_ATR * a.atr)
                                        : (anchor + SWING_BUFFER_ATR * a.atr) - entry;
            double lo1 = SL_MIN_ATR * a.atr, hi1 = SL_MAX_ATR * a.atr;
            if (structDist > hi1) a.stopCapped = true;
            risk = Math.max(lo1, Math.min(hi1, structDist));
        }
        a.entry = entry;
        a.risk = risk;
        a.sl = entry - dir * risk;
        a.tp1 = entry + dir * TP1_R * risk;
        a.tp2 = entry + dir * TP2_R * risk;
        a.rr1 = TP1_R;
        a.rr2 = TP2_R;
        double opposing = wantBuy ? res : sup;
        if (!bad(opposing) && (wantBuy ? opposing < a.tp1 : opposing > a.tp1)) a.obstacle = opposing;
        return a;
    }

    /** True when Bollinger bandwidth is in the lowest 20% of its recent range. */
    private static boolean isSqueeze(Series s, int i) {
        double cur = s.bbWidth[i];
        if (bad(cur)) return false;
        int from = Math.max(0, i - SQUEEZE_LOOKBACK + 1);
        int total = 0, lowerOrEqual = 0;
        for (int k = from; k <= i; k++) {
            double w = s.bbWidth[k];
            if (bad(w)) continue;
            total++;
            if (w <= cur) lowerOrEqual++;
        }
        return total >= 30 && (double) lowerOrEqual / total <= 0.20;
    }

    /** Aggregate result of replaying the rules over history. */
    static final class Backtest {
        int trades, wins, losses, timeouts, open;
        double sumR;

        double winRate() { return trades == 0 ? 0 : (double) wins / trades; }
        double avgR() { return trades == 0 ? 0 : sumR / trades; }
    }

    /**
     * Replays the strategy bar by bar on the first {@code limit} bars (so a still-forming candle can be
     * excluded). Entry is at the bar's close; TP1 vs SL is resolved on following bars, pessimistically
     * (SL wins if both are touched in the same bar). One trade at a time. Ignores spread and slippage.
     */
    static Backtest backtest(Series s, int limit, int maxHold) {
        Backtest bt = new Backtest();
        int n = Math.min(limit, s.n);
        int start = MIN_BARS - 1;
        if (s.firstEma200 >= 0) start = Math.max(start, s.firstEma200);
        int i = start;
        while (i < n - 1) {
            Analysis a = evaluate(s, i, s.c[i]);
            if (!a.isTrade()) { i++; continue; }
            final boolean buy = a.signal == Analysis.Signal.BUY;
            final double dir = buy ? 1.0 : -1.0;
            final int end = i + maxHold;
            int exit = -1;
            double r = 0;
            for (int j = i + 1; j < n && j <= end; j++) {
                boolean hitSl = buy ? s.l[j] <= a.sl : s.h[j] >= a.sl;
                boolean hitTp = buy ? s.h[j] >= a.tp1 : s.l[j] <= a.tp1;
                if (hitSl) { exit = j; r = -1.0; bt.losses++; break; }
                if (hitTp) { exit = j; r = a.rr1; bt.wins++; break; }
            }
            if (exit < 0) {
                if (end <= n - 1) {
                    exit = end;
                    r = dir * (s.c[end] - a.entry) / a.risk;
                    bt.timeouts++;
                } else {
                    bt.open++;
                    break;
                }
            }
            bt.trades++;
            bt.sumR += r;
            i = exit + 1;
        }
        return bt;
    }
}
