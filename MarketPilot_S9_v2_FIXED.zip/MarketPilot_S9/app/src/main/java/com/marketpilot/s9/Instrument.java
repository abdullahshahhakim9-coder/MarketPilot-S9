package com.marketpilot.s9;

import java.util.Locale;

/** Supported symbols plus the market conventions needed for formatting and position sizing. */
enum Instrument {
    //            label      dec  pip     contract  JPY-quote  demo price  demo daily vol
    EURUSD("EUR/USD", 5, 0.0001, 100_000, false, 1.0850, 0.0050),
    GBPUSD("GBP/USD", 5, 0.0001, 100_000, false, 1.3000, 0.0060),
    USDJPY("USD/JPY", 3, 0.01, 100_000, true, 147.00, 0.0065),
    XAUUSD("XAU/USD", 2, 0.0, 100, false, 2650.0, 0.0110),
    XAGUSD("XAG/USD", 3, 0.0, 5_000, false, 31.0, 0.0180);

    final String label;
    final int decimals;
    /** Pip size for FX pairs; 0 for metals (distances are shown in dollars instead). */
    final double pip;
    /** Units of the base asset per 1.00 standard lot (oz for metals). */
    final double contractSize;
    final boolean quoteIsJpy;
    final double demoPrice;
    final double demoDailyVol;

    Instrument(String label, int decimals, double pip, double contractSize, boolean quoteIsJpy,
               double demoPrice, double demoDailyVol) {
        this.label = label;
        this.decimals = decimals;
        this.pip = pip;
        this.contractSize = contractSize;
        this.quoteIsJpy = quoteIsJpy;
        this.demoPrice = demoPrice;
        this.demoDailyVol = demoDailyVol;
    }

    String format(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "—";
        return String.format(Locale.US, "%." + decimals + "f", v);
    }

    /** Human readable price distance: pips for FX, dollars for metals. */
    String formatDistance(double d) {
        d = Math.abs(d);
        if (pip > 0) return String.format(Locale.US, "%.1f pips", d / pip);
        return "$" + format(d);
    }

    /** USD P&L of a 1.0 price move on one standard lot (USD account assumed). */
    double usdPerPriceUnit(double price) {
        if (quoteIsJpy) return price > 0 ? contractSize / price : 0;
        return contractSize;
    }

    static Instrument at(int index) {
        Instrument[] all = values();
        return all[Math.max(0, Math.min(all.length - 1, index))];
    }

    static String[] labels() {
        Instrument[] all = values();
        String[] out = new String[all.length];
        for (int i = 0; i < all.length; i++) out[i] = all[i].label;
        return out;
    }
}
