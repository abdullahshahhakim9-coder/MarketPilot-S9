package com.marketpilot.s9;

/** One OHLC bar. {@code time} is the bar's open time in epoch milliseconds (UTC), or 0 if unknown. */
final class Candle {
    final long time;
    final double open, high, low, close;

    Candle(long time, double open, double high, double low, double close) {
        this.time = time;
        this.open = open;
        this.high = high;
        this.low = low;
        this.close = close;
    }
}
