package com.marketpilot.s9;

import java.util.Arrays;

/**
 * Technical indicators. All functions are causal (value at index i only uses data up to i)
 * and return arrays aligned with the input, with NaN where the indicator is not yet defined.
 * Smoothing follows the conventions used by common charting platforms (Wilder for RSI/ATR/ADX,
 * SMA-seeded EMA).
 */
final class Indicators {
    private Indicators() {}

    static double[] nanArray(int n) {
        double[] a = new double[n];
        Arrays.fill(a, Double.NaN);
        return a;
    }

    static boolean valid(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }

    /** Simple moving average. */
    static double[] sma(double[] v, int n) {
        double[] out = nanArray(v.length);
        if (n <= 0 || v.length < n) return out;
        double sum = 0;
        for (int i = 0; i < v.length; i++) {
            sum += v[i];
            if (i >= n) sum -= v[i - n];
            if (i >= n - 1) out[i] = sum / n;
        }
        return out;
    }

    /**
     * Exponential moving average seeded with the SMA of the first {@code n} valid values.
     * Leading NaNs in the input are skipped, so it can be applied to another indicator (e.g. MACD).
     */
    static double[] ema(double[] v, int n) {
        double[] out = nanArray(v.length);
        if (n <= 0) return out;
        int s = 0;
        while (s < v.length && !valid(v[s])) s++;
        if (v.length - s < n) return out;
        double sum = 0;
        for (int i = s; i < s + n; i++) sum += v[i];
        double e = sum / n;
        out[s + n - 1] = e;
        double k = 2.0 / (n + 1);
        for (int i = s + n; i < v.length; i++) {
            e = v[i] * k + e * (1 - k);
            out[i] = e;
        }
        return out;
    }

    private static double rsiValue(double avgGain, double avgLoss) {
        if (avgLoss == 0) return avgGain == 0 ? 50.0 : 100.0;
        return 100.0 - 100.0 / (1.0 + avgGain / avgLoss);
    }

    /** Wilder RSI. First value at index n. */
    static double[] rsi(double[] c, int n) {
        double[] out = nanArray(c.length);
        if (n <= 0 || c.length <= n) return out;
        double g = 0, l = 0;
        for (int i = 1; i <= n; i++) {
            double d = c[i] - c[i - 1];
            if (d > 0) g += d; else l -= d;
        }
        g /= n;
        l /= n;
        out[n] = rsiValue(g, l);
        for (int i = n + 1; i < c.length; i++) {
            double d = c[i] - c[i - 1];
            double gain = d > 0 ? d : 0;
            double loss = d < 0 ? -d : 0;
            g = (g * (n - 1) + gain) / n;
            l = (l * (n - 1) + loss) / n;
            out[i] = rsiValue(g, l);
        }
        return out;
    }

    static double[] trueRange(double[] h, double[] l, double[] c) {
        double[] tr = new double[c.length];
        for (int i = 0; i < c.length; i++) {
            if (i == 0) {
                tr[i] = h[i] - l[i];
            } else {
                tr[i] = Math.max(h[i] - l[i], Math.max(Math.abs(h[i] - c[i - 1]), Math.abs(l[i] - c[i - 1])));
            }
        }
        return tr;
    }

    /** Wilder ATR. First value at index n-1. */
    static double[] atr(double[] h, double[] l, double[] c, int n) {
        double[] out = nanArray(c.length);
        if (n <= 0 || c.length < n) return out;
        double[] tr = trueRange(h, l, c);
        double a = 0;
        for (int i = 0; i < n; i++) a += tr[i];
        a /= n;
        out[n - 1] = a;
        for (int i = n; i < c.length; i++) {
            a = (a * (n - 1) + tr[i]) / n;
            out[i] = a;
        }
        return out;
    }

    /** MACD: returns {macdLine, signalLine, histogram}. */
    static double[][] macd(double[] c, int fast, int slow, int signal) {
        double[] f = ema(c, fast);
        double[] s = ema(c, slow);
        double[] line = nanArray(c.length);
        for (int i = 0; i < c.length; i++) {
            if (valid(f[i]) && valid(s[i])) line[i] = f[i] - s[i];
        }
        double[] sig = ema(line, signal);
        double[] hist = nanArray(c.length);
        for (int i = 0; i < c.length; i++) {
            if (valid(line[i]) && valid(sig[i])) hist[i] = line[i] - sig[i];
        }
        return new double[][]{line, sig, hist};
    }

    /** Bollinger bands with population standard deviation: returns {mid, upper, lower}. */
    static double[][] bollinger(double[] c, int n, double k) {
        double[] mid = sma(c, n);
        double[] up = nanArray(c.length);
        double[] lo = nanArray(c.length);
        for (int i = n - 1; i < c.length; i++) {
            double m = mid[i], ss = 0;
            for (int j = i - n + 1; j <= i; j++) ss += (c[j] - m) * (c[j] - m);
            double sd = Math.sqrt(ss / n);
            up[i] = m + k * sd;
            lo[i] = m - k * sd;
        }
        return new double[][]{mid, up, lo};
    }

    /** Wilder ADX with directional indicators: returns {adx, +DI, -DI}. First ADX at index 2n-1. */
    static double[][] adx(double[] h, double[] l, double[] c, int n) {
        int len = c.length;
        double[] adx = nanArray(len), pdi = nanArray(len), mdi = nanArray(len);
        if (n <= 0 || len < 2 * n) return new double[][]{adx, pdi, mdi};
        double[] tr = trueRange(h, l, c);
        double[] pdm = new double[len], mdm = new double[len];
        for (int i = 1; i < len; i++) {
            double up = h[i] - h[i - 1];
            double down = l[i - 1] - l[i];
            pdm[i] = (up > down && up > 0) ? up : 0;
            mdm[i] = (down > up && down > 0) ? down : 0;
        }
        double sTr = 0, sP = 0, sM = 0;
        for (int i = 1; i <= n; i++) {
            sTr += tr[i];
            sP += pdm[i];
            sM += mdm[i];
        }
        double[] dx = nanArray(len);
        for (int i = n; i < len; i++) {
            if (i > n) {
                sTr = sTr - sTr / n + tr[i];
                sP = sP - sP / n + pdm[i];
                sM = sM - sM / n + mdm[i];
            }
            double p = sTr > 0 ? 100.0 * sP / sTr : 0;
            double m = sTr > 0 ? 100.0 * sM / sTr : 0;
            pdi[i] = p;
            mdi[i] = m;
            dx[i] = (p + m) > 0 ? 100.0 * Math.abs(p - m) / (p + m) : 0;
        }
        double a = 0;
        for (int i = n; i < 2 * n; i++) a += dx[i];
        a /= n;
        adx[2 * n - 1] = a;
        for (int i = 2 * n; i < len; i++) {
            a = (a * (n - 1) + dx[i]) / n;
            adx[i] = a;
        }
        return new double[][]{adx, pdi, mdi};
    }

    /**
     * Swing highs: bar is strictly higher than the {@code left} bars before it and at least as high
     * as the {@code right} bars after it. A swing is only confirmed {@code right} bars later.
     */
    static int[] swingHighs(double[] h, int left, int right) {
        int[] tmp = new int[h.length];
        int cnt = 0;
        for (int i = left; i <= h.length - 1 - right; i++) {
            boolean ok = true;
            for (int k = 1; k <= left && ok; k++) if (!(h[i] > h[i - k])) ok = false;
            for (int k = 1; k <= right && ok; k++) if (!(h[i] >= h[i + k])) ok = false;
            if (ok) tmp[cnt++] = i;
        }
        return Arrays.copyOf(tmp, cnt);
    }

    /** Mirror image of {@link #swingHighs} for lows. */
    static int[] swingLows(double[] l, int left, int right) {
        int[] tmp = new int[l.length];
        int cnt = 0;
        for (int i = left; i <= l.length - 1 - right; i++) {
            boolean ok = true;
            for (int k = 1; k <= left && ok; k++) if (!(l[i] < l[i - k])) ok = false;
            for (int k = 1; k <= right && ok; k++) if (!(l[i] <= l[i + k])) ok = false;
            if (ok) tmp[cnt++] = i;
        }
        return Arrays.copyOf(tmp, cnt);
    }
}
