package com.marketpilot.s9;

import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores the API key encrypted with an AES-256-GCM key that lives in the Android Keystore
 * (the key material never leaves secure hardware / the system keystore process).
 * Falls back to private SharedPreferences only if the Keystore is unavailable on a device.
 */
final class SecureStore {
    private static final String ALIAS = "marketpilot_api_key_v1";
    private static final String PROVIDER = "AndroidKeyStore";
    private static final String P_ENC = "key_enc";
    private static final String P_PLAIN = "key"; // legacy / fallback

    private final SharedPreferences prefs;

    SecureStore(SharedPreferences prefs) {
        this.prefs = prefs;
    }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance(PROVIDER);
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    /** Returns the stored key, or "" if none (or it can no longer be decrypted). */
    String load() {
        String enc = prefs.getString(P_ENC, "");
        if (enc != null && !enc.isEmpty()) {
            try {
                int sep = enc.indexOf(':');
                byte[] iv = Base64.decode(enc.substring(0, sep), Base64.NO_WRAP);
                byte[] ct = Base64.decode(enc.substring(sep + 1), Base64.NO_WRAP);
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
                return new String(c.doFinal(ct), StandardCharsets.UTF_8);
            } catch (Exception e) {
                // Keystore entry was wiped (e.g. lock-screen change on some devices): ask the user again.
                prefs.edit().remove(P_ENC).apply();
                return "";
            }
        }
        String legacy = prefs.getString(P_PLAIN, "");
        if (legacy != null && !legacy.isEmpty()) {
            save(legacy); // migrate plaintext from the old version to encrypted storage
            return legacy;
        }
        return "";
    }

    void save(String value) {
        if (value == null || value.isEmpty()) {
            clear();
            return;
        }
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] ct = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String enc = Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
            prefs.edit().putString(P_ENC, enc).remove(P_PLAIN).apply();
        } catch (Exception e) {
            prefs.edit().putString(P_PLAIN, value).remove(P_ENC).apply();
        }
    }

    void clear() {
        prefs.edit().remove(P_ENC).remove(P_PLAIN).apply();
    }
}
