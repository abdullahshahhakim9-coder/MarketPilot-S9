package com.marketpilot.s9;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.View;

/** Candlestick chart with EMA20/50/200, Bollinger bands and trade levels. Draws the most recent bars. */
final class ChartView extends View {
    private static final int VISIBLE_BARS = 90;

    static final int UP = 0xFF22C55E, DOWN = 0xFFEF4444;
    static final int C_EMA20 = 0xFFF59E0B, C_EMA50 = 0xFF38BDF8, C_EMA200 = 0xFFA78BFA;
    private static final int C_BB = 0x80CBD5E1, C_GRID = 0x22FFFFFF, C_MUTED = 0xFF94A3B8, C_TEXT = 0xFFF8FAFC;
    private static final int C_ENTRY = 0xFFF8FAFC;

    private final float density;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dashed = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    private Series series;
    private Analysis analysis;
    private Instrument inst = Instrument.EURUSD;
    private boolean simulated;
    private String emptyMessage = "No data";

    // Per-draw coordinate mapping.
    private double vMax, vSpan;
    private float plotTop, plotHeight, plotLeft, slot;
    private int firstBar;

    ChartView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        dashed.setStyle(Paint.Style.STROKE);
        dashed.setStrokeWidth(dp(1));
        dashed.setPathEffect(new DashPathEffect(new float[]{dp(5), dp(4)}, 0));
        text.setTextSize(dp(9));
        setContentDescription("Candlestick price chart with moving averages and trade levels");
    }

    private float dp(float v) {
        return v * density;
    }

    void setData(Series s, Analysis a, Instrument i, boolean isSimulated) {
        series = s;
        analysis = a;
        inst = i;
        simulated = isSimulated;
        invalidate();
    }

    void clear(String message) {
        series = null;
        analysis = null;
        emptyMessage = message;
        invalidate();
    }

    private float x(int bar) {
        return plotLeft + slot * (bar - firstBar) + slot / 2f;
    }

    private float y(double v) {
        return (float) (plotTop + (vMax - v) / vSpan * plotHeight);
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        final int w = getWidth(), h = getHeight();
        final Series s = series;
        if (s == null || s.n < 5) {
            text.setColor(C_MUTED);
            text.setTextSize(dp(12));
            text.setTextAlign(Paint.Align.CENTER);
            cv.drawText(emptyMessage, w / 2f, h / 2f, text);
            text.setTextSize(dp(9));
            text.setTextAlign(Paint.Align.LEFT);
            return;
        }
        final float right = dp(54), left = dp(6), top = dp(26), bottom = dp(8);
        final float cw = w - left - right, ch = h - top - bottom;
        if (cw <= 0 || ch <= 0) return;

        final int visible = Math.min(VISIBLE_BARS, s.n);
        firstBar = s.n - visible;
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (int k = firstBar; k < s.n; k++) {
            min = Math.min(min, s.l[k]);
            max = Math.max(max, s.h[k]);
        }
        final Analysis a = analysis;
        final boolean levels = a != null && a.isTrade();
        if (levels) {
            min = Math.min(min, Math.min(a.sl, Math.min(a.tp1, a.tp2)));
            max = Math.max(max, Math.max(a.sl, Math.max(a.tp1, a.tp2)));
        }
        double pad = (max - min) * 0.06;
        if (!(pad > 0)) pad = Math.abs(max) * 1e-4 + 1e-9;
        min -= pad;
        max += pad;
        vMax = max;
        vSpan = max - min;
        plotTop = top;
        plotHeight = ch;
        plotLeft = left;
        slot = cw / visible;

        // Grid + axis labels
        text.setColor(C_MUTED);
        text.setTextAlign(Paint.Align.LEFT);
        stroke.setStrokeWidth(dp(0.5f));
        stroke.setColor(C_GRID);
        for (int g = 0; g <= 4; g++) {
            float gy = top + ch * g / 4f;
            cv.drawLine(left, gy, left + cw, gy, stroke);
            double v = max - vSpan * g / 4.0;
            cv.drawText(inst.format(v), left + cw + dp(4), gy + dp(3), text);
        }

        cv.save();
        cv.clipRect(left, top, left + cw, top + ch);

        plot(cv, s.bbUp, C_BB, dp(0.8f));
        plot(cv, s.bbLo, C_BB, dp(0.8f));
        plot(cv, s.ema200, C_EMA200, dp(1.4f));
        plot(cv, s.ema50, C_EMA50, dp(1.4f));
        plot(cv, s.ema20, C_EMA20, dp(1.4f));

        // Candles
        final float bodyHalf = Math.max(dp(0.8f), slot * 0.34f);
        stroke.setStrokeWidth(Math.max(1f, dp(1f)));
        for (int k = firstBar; k < s.n; k++) {
            final boolean bull = s.c[k] >= s.o[k];
            final int col = bull ? UP : DOWN;
            final float cx = x(k);
            stroke.setColor(col);
            cv.drawLine(cx, y(s.h[k]), cx, y(s.l[k]), stroke);
            float yo = y(s.o[k]), yc = y(s.c[k]);
            float yt = Math.min(yo, yc), yb = Math.max(yo, yc);
            if (yb - yt < 1f) yb = yt + 1f;
            fill.setColor(col);
            fill.setStyle(Paint.Style.FILL);
            cv.drawRect(cx - bodyHalf, yt, cx + bodyHalf, yb, fill);
        }

        if (levels) {
            level(cv, a.entry, C_ENTRY, "ENTRY", left, cw);
            level(cv, a.sl, DOWN, "SL", left, cw);
            level(cv, a.tp1, UP, "TP1", left, cw);
            level(cv, a.tp2, UP, "TP2", left, cw);
        }
        cv.restore();

        // Last price tag
        final int last = s.n - 1;
        final float ly = y(s.c[last]);
        final int tagColor = s.c[last] >= s.o[last] ? UP : DOWN;
        fill.setColor(tagColor);
        cv.drawRect(left + cw + dp(1), ly - dp(7), w - dp(1), ly + dp(7), fill);
        text.setColor(0xFF0A0E17);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        cv.drawText(inst.format(s.c[last]), left + cw + dp(4), ly + dp(3), text);
        text.setTypeface(Typeface.DEFAULT);

        // Legend
        float lx = left + dp(4);
        lx = legend(cv, "EMA20", C_EMA20, lx, dp(14));
        lx = legend(cv, "EMA50", C_EMA50, lx, dp(14));
        lx = legend(cv, s.firstEma200 >= 0 ? "EMA200" : "EMA200 n/a", C_EMA200, lx, dp(14));
        legend(cv, "BB(20,2)", C_BB, lx, dp(14));

        if (simulated) {
            cv.save();
            cv.rotate(-18f, w / 2f, h / 2f);
            text.setColor(0x30FFFFFF);
            text.setTextSize(dp(26));
            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(Typeface.DEFAULT_BOLD);
            cv.drawText("SIMULATED DATA", w / 2f, h / 2f, text);
            cv.restore();
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(dp(9));
            text.setTextAlign(Paint.Align.LEFT);
        }
    }

    private float legend(Canvas cv, String label, int color, float x, float y) {
        fill.setColor(color);
        cv.drawRect(x, y - dp(5), x + dp(8), y - dp(1), fill);
        text.setColor(C_MUTED);
        text.setTextAlign(Paint.Align.LEFT);
        cv.drawText(label, x + dp(11), y, text);
        return x + dp(11) + text.measureText(label) + dp(10);
    }

    private void plot(Canvas cv, double[] values, int color, float width) {
        path.reset();
        boolean pen = false;
        for (int k = firstBar; k < series.n; k++) {
            double v = values[k];
            if (Double.isNaN(v)) { pen = false; continue; }
            float px = x(k), py = y(v);
            if (!pen) { path.moveTo(px, py); pen = true; } else { path.lineTo(px, py); }
        }
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        cv.drawPath(path, stroke);
    }

    private void level(Canvas cv, double price, int color, String label, float left, float cw) {
        float ly = y(price);
        dashed.setColor(color);
        cv.drawLine(left, ly, left + cw, ly, dashed);
        text.setColor(color);
        text.setTextAlign(Paint.Align.LEFT);
        cv.drawText(label + " " + inst.format(price), left + dp(4), ly - dp(2), text);
    }
}
