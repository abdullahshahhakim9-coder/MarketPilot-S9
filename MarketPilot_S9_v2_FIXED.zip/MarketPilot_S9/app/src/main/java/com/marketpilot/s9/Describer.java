package com.marketpilot.s9;

import java.util.ArrayList;
import java.util.Locale;

/** Turns an {@link Analysis} into the short explanations shown in the UI. */
final class Describer {
    private Describer() {}

    static final class Text {
        String headline = "";
        String meta = "";
        String trend = "", momentum = "", volatility = "", structure = "";
        final ArrayList<String> notes = new ArrayList<>();
    }

    static String signed(int v) {
        return v > 0 ? "+" + v : String.valueOf(v);
    }

    private static String f1(double v) {
        return String.format(Locale.US, "%.1f", v);
    }

    static Text describe(Analysis a, Instrument inst) {
        Text t = new Text();
        if (a.insufficient) {
            t.headline = "Not enough data to analyse yet";
            t.notes.add("At least " + SignalEngine.MIN_BARS + " candles with valid indicators are required.");
            return t;
        }

        // Headline
        if (a.signal == Analysis.Signal.BUY) {
            t.headline = a.score >= 7 ? "Strong bullish confluence" : "Moderate bullish confluence";
        } else if (a.signal == Analysis.Signal.SELL) {
            t.headline = a.score <= -7 ? "Strong bearish confluence" : "Moderate bearish confluence";
        } else if (a.candidate != null) {
            t.headline = (a.candidate == Analysis.Signal.BUY ? "Bullish lean" : "Bearish lean") + " — held back by a safety filter";
        } else if (a.score > 0) {
            t.headline = "Mixed evidence, slight bullish lean";
        } else if (a.score < 0) {
            t.headline = "Mixed evidence, slight bearish lean";
        } else {
            t.headline = "Mixed evidence, no edge";
        }

        t.meta = "RSI " + f1(a.rsi)
                + "  ·  ADX " + String.format(Locale.US, "%.0f", a.adx) + " " + a.regime.toLowerCase(Locale.US)
                + "  ·  ATR " + inst.formatDistance(a.atr)
                + "  ·  MACD " + (a.macdHist > 0 ? "▲" : (a.macdHist < 0 ? "▼" : "–"));

        // Components
        t.trend = (a.close > a.ema20 ? "Price > EMA20" : (a.close < a.ema20 ? "Price < EMA20" : "Price = EMA20"))
                + "  ·  " + (a.ema20 > a.ema50 ? "EMA20 > EMA50" : (a.ema20 < a.ema50 ? "EMA20 < EMA50" : "EMA20 = EMA50"))
                + "  ·  " + (!a.hasEma200 ? "EMA200 n/a" : (a.ema50 > a.ema200 ? "EMA50 > EMA200" : (a.ema50 < a.ema200 ? "EMA50 < EMA200" : "EMA50 = EMA200")));

        t.momentum = "RSI " + f1(a.rsi) + (a.rsi > SignalEngine.RSI_BULL ? " bullish" : (a.rsi < SignalEngine.RSI_BEAR ? " bearish" : " neutral"))
                + "  ·  MACD histogram " + (a.macdHist > 0 ? "positive" : (a.macdHist < 0 ? "negative" : "flat"));

        String pb = String.format(Locale.US, "%%B %.2f", a.pctB);
        if (a.adx >= SignalEngine.ADX_STRONG) t.volatility = pb + "  ·  strong trend, band-walk not counted against it";
        else if (a.pctB > 1.0) t.volatility = pb + "  ·  above upper band (stretched)";
        else if (a.pctB < 0.0) t.volatility = pb + "  ·  below lower band (stretched)";
        else t.volatility = pb + "  ·  inside the bands";

        String swing = a.structureTrend > 0 ? "Higher highs + higher lows" : (a.structureTrend < 0 ? "Lower highs + lower lows" : "Mixed swings");
        if (a.brokeUp) swing += "  ·  closed above swing high " + inst.format(a.lastSwingHigh);
        else if (a.brokeDown) swing += "  ·  closed below swing low " + inst.format(a.lastSwingLow);
        t.structure = swing;

        // Notes
        if (a.candidate != null && a.signal == Analysis.Signal.WAIT) {
            String dir = a.candidate == Analysis.Signal.BUY ? "BUY" : "SELL";
            if (a.blockedRegime) {
                t.notes.add(dir + " blocked: ADX " + String.format(Locale.US, "%.0f", a.adx) + " is under "
                        + (int) SignalEngine.ADX_RANGING + " — the market is ranging and trend signals are unreliable.");
            }
            if (a.blockedTrend) {
                t.notes.add(dir + " blocked: the EMAs don't back it (trend " + signed(a.trend) + ", needs "
                        + (a.candidate == Analysis.Signal.BUY ? "+2 or more" : "-2 or less") + ").");
            }
            if (a.blockedRsi) {
                t.notes.add(dir + " blocked: RSI " + f1(a.rsi) + " is at an extreme, which makes chasing risky.");
            }
        } else if (a.blockedScore) {
            t.notes.add("Score " + signed(a.score) + " is inside ±" + SignalEngine.SCORE_THRESHOLD
                    + " — the evidence is mixed, so WAIT is intentional.");
        }
        if (a.squeeze) t.notes.add("Bollinger squeeze: volatility is compressed, so a breakout may follow (direction unconfirmed).");
        if (a.rsiStretched) t.notes.add("RSI " + f1(a.rsi) + " is stretched; late entries carry pullback risk.");
        if (!Double.isNaN(a.obstacle)) {
            t.notes.add("Nearby " + (a.signal == Analysis.Signal.BUY ? "resistance" : "support") + " at "
                    + inst.format(a.obstacle) + " sits before TP1 — consider taking profit earlier.");
        }
        if (a.stopCapped) t.notes.add("The swing-based stop was wider than " + (int) SignalEngine.SL_MAX_ATR + "×ATR and was capped.");
        if (!a.hasEma200) t.notes.add("EMA200 needs 200+ candles; trend currently uses 2 of 3 EMA checks.");
        return t;
    }
}
