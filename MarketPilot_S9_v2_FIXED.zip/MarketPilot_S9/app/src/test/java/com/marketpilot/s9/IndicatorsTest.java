package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class IndicatorsTest {
    private static final double EPS = 1e-9;

    @Test
    public void smaMatchesHandCalculation() {
        double[] s = Indicators.sma(new double[]{1, 2, 3, 4, 5}, 3);
        assertTrue(Double.isNaN(s[0]) && Double.isNaN(s[1]));
        assertEquals(2.0, s[2], EPS);
        assertEquals(3.0, s[3], EPS);
        assertEquals(4.0, s[4], EPS);
    }

    @Test
    public void emaIsSeededWithSmaAndLagsARampByHalfNMinusOne() {
        double[] v = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        double[] e = Indicators.ema(v, 3);
        assertTrue(Double.isNaN(e[1]));
        assertEquals(2.0, e[2], EPS); // SMA(1,2,3)
        for (int i = 2; i < v.length; i++) assertEquals(v[i] - 1.0, e[i], EPS);
    }

    @Test
    public void emaOfConstantIsConstantAndNeedsEnoughData() {
        double[] flat = new double[50];
        java.util.Arrays.fill(flat, 7.5);
        assertEquals(7.5, Indicators.ema(flat, 20)[49], EPS);
        assertTrue(Double.isNaN(Indicators.ema(new double[10], 20)[9]));
    }

    @Test
    public void rsiExtremesAndFlat() {
        double[] up = new double[40], down = new double[40], flat = new double[40];
        for (int i = 0; i < 40; i++) { up[i] = 100 + i; down[i] = 100 - i; flat[i] = 100; }
        assertEquals(100.0, Indicators.rsi(up, 14)[39], EPS);
        assertEquals(0.0, Indicators.rsi(down, 14)[39], EPS);
        assertEquals(50.0, Indicators.rsi(flat, 14)[39], EPS);
        assertTrue(Double.isNaN(Indicators.rsi(up, 14)[13]));
        assertTrue(Indicators.valid(Indicators.rsi(up, 14)[14]));
    }

    @Test
    public void rsiMatchesPublishedWilderWorksheet() {
        // Classic StockCharts RSI example (4-decimal prices): first values are about 70.5, 66.3, 66.6.
        double[] px = {44.3389, 44.0902, 44.1497, 43.6124, 44.3278, 44.8264, 45.0955, 45.4766, 45.8434,
                46.0826, 45.8943, 46.0326, 45.6140, 46.2820, 46.2820, 46.0028, 46.0328, 46.4116};
        double[] r = Indicators.rsi(px, 14);
        assertEquals(70.5, r[14], 0.2);
        assertEquals(66.3, r[15], 0.2);
        assertEquals(66.6, r[16], 0.2);
    }

    @Test
    public void atrOfConstantRangeEqualsRange() {
        int n = 40;
        double[] h = new double[n], l = new double[n], c = new double[n];
        for (int i = 0; i < n; i++) { h[i] = 101; l[i] = 99; c[i] = 100; }
        double[] a = Indicators.atr(h, l, c, 14);
        assertTrue(Double.isNaN(a[12]));
        assertEquals(2.0, a[13], EPS);
        assertEquals(2.0, a[39], EPS);
    }

    @Test
    public void atrCapturesGaps() {
        double[] h = {10, 10, 20}, l = {9, 9, 19}, c = {9.5, 9.5, 19.5};
        double[] tr = Indicators.trueRange(h, l, c);
        assertEquals(1.0, tr[1], EPS);
        assertEquals(10.5, tr[2], EPS); // |high - prevClose| dominates
    }

    @Test
    public void macdHistogramIsLineMinusSignal() {
        double[] c = new double[120];
        for (int i = 0; i < c.length; i++) c[i] = 100 + Math.sin(i / 7.0) * 3 + i * 0.05;
        double[][] m = Indicators.macd(c, 12, 26, 9);
        assertTrue(Double.isNaN(m[0][24]));
        assertTrue(Indicators.valid(m[0][25]));
        assertTrue(Double.isNaN(m[1][32]));
        assertTrue(Indicators.valid(m[1][33]));
        for (int i = 33; i < c.length; i++) assertEquals(m[0][i] - m[1][i], m[2][i], EPS);
    }

    @Test
    public void bollingerBandsAreSymmetricAndZeroWidthWhenFlat() {
        double[] flat = new double[30];
        java.util.Arrays.fill(flat, 5);
        double[][] b = Indicators.bollinger(flat, 20, 2);
        assertEquals(5.0, b[1][29], EPS);
        assertEquals(5.0, b[2][29], EPS);
        double[] v = new double[30];
        for (int i = 0; i < 30; i++) v[i] = i % 2 == 0 ? 9 : 11; // mean 10, population sd 1
        double[][] k = Indicators.bollinger(v, 20, 2);
        assertEquals(10.0, k[0][29], EPS);
        assertEquals(12.0, k[1][29], EPS);
        assertEquals(8.0, k[2][29], EPS);
    }

    @Test
    public void adxIsHighInCleanTrendAndLowInChop() {
        int n = 120;
        double[] h = new double[n], l = new double[n], c = new double[n];
        double[] h2 = new double[n], l2 = new double[n], c2 = new double[n];
        for (int i = 0; i < n; i++) {
            c[i] = 100 + i; h[i] = c[i] + 0.5; l[i] = c[i] - 0.5;
            c2[i] = 100 + (i % 2 == 0 ? 0.5 : -0.5); h2[i] = c2[i] + 0.3; l2[i] = c2[i] - 0.3;
        }
        double[][] trend = Indicators.adx(h, l, c, 14);
        double[][] chop = Indicators.adx(h2, l2, c2, 14);
        assertTrue(Double.isNaN(trend[0][26]));
        assertTrue(Indicators.valid(trend[0][27]));
        assertTrue("trend ADX " + trend[0][n - 1], trend[0][n - 1] > 40);
        assertTrue("chop ADX " + chop[0][n - 1], chop[0][n - 1] < 15);
        assertTrue(trend[1][n - 1] > trend[2][n - 1]); // +DI above -DI in an uptrend
    }

    @Test
    public void swingsRequireConfirmationAndStrictLeft() {
        double[] h = {1, 2, 3, 9, 3, 2, 1, 1, 1, 1, 1, 1, 1};
        int[] sh = Indicators.swingHighs(h, 3, 3);
        assertEquals(1, sh.length);
        assertEquals(3, sh[0]);
        double[] l = {9, 8, 7, 1, 7, 8, 9};
        int[] sl = Indicators.swingLows(l, 3, 3);
        assertEquals(1, sl.length);
        assertEquals(3, sl[0]);
        // a peak in the last 'right' bars is not yet confirmed
        assertEquals(0, Indicators.swingHighs(new double[]{1, 2, 3, 4, 9, 3}, 3, 3).length);
        // equal adjacent highs register once
        assertEquals(1, Indicators.swingHighs(new double[]{1, 2, 3, 9, 9, 3, 2, 1}, 3, 3).length);
    }
}
