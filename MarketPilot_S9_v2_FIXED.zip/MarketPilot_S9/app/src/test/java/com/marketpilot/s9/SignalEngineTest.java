package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

public class SignalEngineTest {
    private static final double EPS = 1e-7;

    private static int count(Series s, Analysis.Signal which) {
        int n = 0;
        for (int i = SignalEngine.MIN_BARS - 1; i < s.n; i++) {
            if (SignalEngine.evaluate(s, i, s.c[i]).signal == which) n++;
        }
        return n;
    }

    @Test
    public void tooFewBarsIsInsufficientNotACrash() {
        Series s = new Series(TestData.randomWalk(1, 40, 0, 1));
        Analysis a = SignalEngine.evaluate(s, 39, s.c[39]);
        assertTrue(a.insufficient);
        assertEquals(Analysis.Signal.WAIT, a.signal);
        assertFalse(a.isTrade());
    }

    @Test
    public void flatMarketHasZeroAtrAndIsInsufficient() {
        double[] flat = new double[200];
        java.util.Arrays.fill(flat, 1.1);
        Series s = new Series(TestData.fromCloses(flat, 0, 3_600_000L));
        Analysis a = SignalEngine.evaluate(s, 199, 1.1);
        assertTrue(a.insufficient);
        assertEquals(Analysis.Signal.WAIT, a.signal);
    }

    @Test
    public void outOfRangeIndexIsSafe() {
        Series s = new Series(TestData.randomWalk(2, 100, 0, 1));
        assertTrue(SignalEngine.evaluate(s, 500, 100).insufficient);
        assertTrue(SignalEngine.evaluate(s, -1, 100).insufficient);
    }

    @Test
    public void emptyAndTinySeriesDoNotThrow() {
        Series empty = new Series(new java.util.ArrayList<Candle>());
        assertEquals(0, empty.n);
        assertEquals(0, SignalEngine.backtest(empty, 0, 48).trades);
    }

    @Test
    public void uptrendWithPullbacksOnlyEverBuys() {
        Series s = new Series(TestData.pullbackTrend(700, 0.25, 3.0, 6.0));
        assertEquals(0, count(s, Analysis.Signal.SELL));
        assertTrue("expected some BUY signals", count(s, Analysis.Signal.BUY) > 0);
    }

    @Test
    public void downtrendWithPullbacksOnlyEverSells() {
        Series s = new Series(TestData.mirror(TestData.pullbackTrend(700, 0.25, 3.0, 6.0), 400));
        assertEquals(0, count(s, Analysis.Signal.BUY));
        assertTrue("expected some SELL signals", count(s, Analysis.Signal.SELL) > 0);
    }

    @Test
    public void tradeLevelsAreCoherent() {
        Series s = new Series(TestData.pullbackTrend(700, 0.25, 3.0, 6.0));
        int checked = 0;
        for (int i = SignalEngine.MIN_BARS - 1; i < s.n; i++) {
            Analysis a = SignalEngine.evaluate(s, i, s.c[i]);
            if (!a.isTrade()) continue;
            checked++;
            assertTrue(a.sl < a.entry && a.entry < a.tp1 && a.tp1 < a.tp2);
            double risk = a.entry - a.sl;
            assertEquals(risk, a.risk, EPS);
            assertEquals(a.entry + SignalEngine.TP1_R * risk, a.tp1, EPS);
            assertEquals(a.entry + SignalEngine.TP2_R * risk, a.tp2, EPS);
            assertTrue(a.risk >= SignalEngine.SL_MIN_ATR * a.atr - EPS);
            assertTrue(a.risk <= SignalEngine.SL_MAX_ATR * a.atr + EPS);
            assertTrue(a.score >= SignalEngine.SCORE_THRESHOLD);
            assertTrue(a.trend >= 2);
            assertTrue(a.adx >= SignalEngine.ADX_RANGING);
            assertTrue(a.rsi < SignalEngine.RSI_EXHAUST_HI);
        }
        assertTrue(checked > 0);
    }

    @Test
    public void waitNeverCarriesTradeLevels() {
        Series s = new Series(TestData.randomWalk(5, 600, 0, 1));
        for (int i = SignalEngine.MIN_BARS - 1; i < s.n; i++) {
            Analysis a = SignalEngine.evaluate(s, i, s.c[i]);
            if (a.isTrade()) continue;
            assertTrue(Double.isNaN(a.entry) && Double.isNaN(a.sl) && Double.isNaN(a.tp1) && Double.isNaN(a.tp2));
        }
    }

    @Test
    public void scoreComponentsStayInDocumentedRanges() {
        for (long seed = 1; seed <= 5; seed++) {
            Series s = new Series(TestData.randomWalk(seed, 500, seed % 2 == 0 ? 0.05 : -0.05, 1));
            for (int i = SignalEngine.MIN_BARS - 1; i < s.n; i++) {
                Analysis a = SignalEngine.evaluate(s, i, s.c[i]);
                if (a.insufficient) continue;
                assertTrue(Math.abs(a.trend) <= 3 && Math.abs(a.momentum) <= 2 && Math.abs(a.volatility) <= 1 && Math.abs(a.structure) <= 2);
                assertEquals(a.trend + a.momentum + a.volatility + a.structure, a.score);
                assertTrue(Math.abs(a.score) <= SignalEngine.MAX_SCORE);
            }
        }
    }

    /** A mirrored market must produce exactly the mirrored analysis: no hidden bullish/bearish bias. */
    @Test
    public void mirrorImageMarketGivesOppositeAnalysis() {
        final double k = 400;
        for (long seed = 1; seed <= 4; seed++) {
            List<Candle> base = TestData.randomWalk(seed, 450, 0.03, 1.0);
            Series a = new Series(base);
            Series b = new Series(TestData.mirror(base, k));
            for (int i = SignalEngine.MIN_BARS - 1; i < a.n; i++) {
                Analysis x = SignalEngine.evaluate(a, i, a.c[i]);
                Analysis y = SignalEngine.evaluate(b, i, b.c[i]);
                String where = "seed " + seed + " bar " + i;
                assertEquals(where, x.insufficient, y.insufficient);
                if (x.insufficient) continue;
                assertEquals(where, -x.score, y.score);
                assertEquals(where, -x.trend, y.trend);
                assertEquals(where, -x.momentum, y.momentum);
                assertEquals(where, -x.volatility, y.volatility);
                assertEquals(where, -x.structure, y.structure);
                Analysis.Signal flipped = x.signal == Analysis.Signal.BUY ? Analysis.Signal.SELL
                        : (x.signal == Analysis.Signal.SELL ? Analysis.Signal.BUY : Analysis.Signal.WAIT);
                assertEquals(where, flipped, y.signal);
                if (x.isTrade()) {
                    assertEquals(where, k - x.sl, y.sl, EPS);
                    assertEquals(where, k - x.tp1, y.tp1, EPS);
                    assertEquals(where, k - x.tp2, y.tp2, EPS);
                }
            }
        }
    }

    /** The signal at bar i may only depend on bars up to i. This is what makes the history check honest. */
    @Test
    public void noLookahead() {
        List<Candle> all = TestData.randomWalk(9, 500, 0.02, 1.0);
        Series full = new Series(all);
        for (int i = 80; i < 500; i += 23) {
            Series cut = new Series(all.subList(0, i + 1));
            Analysis x = SignalEngine.evaluate(full, i, full.c[i]);
            Analysis y = SignalEngine.evaluate(cut, i, cut.c[i]);
            assertEquals("bar " + i, x.score, y.score);
            assertEquals("bar " + i, x.signal, y.signal);
            assertEquals("bar " + i, x.support, y.support, EPS);
            assertEquals("bar " + i, x.resistance, y.resistance, EPS);
            if (x.isTrade()) {
                assertEquals("bar " + i, x.sl, y.sl, EPS);
                assertEquals("bar " + i, x.tp1, y.tp1, EPS);
            }
        }
    }

    @Test
    public void backtestBookkeepingIsConsistent() {
        Series s = new Series(TestData.pullbackTrend(900, 0.25, 3.0, 6.0));
        SignalEngine.Backtest bt = SignalEngine.backtest(s, s.n, 48);
        assertTrue(bt.trades > 0);
        assertEquals(bt.trades, bt.wins + bt.losses + bt.timeouts);
        assertEquals(bt.sumR / bt.trades, bt.avgR(), 1e-12);
        assertEquals((double) bt.wins / bt.trades, bt.winRate(), 1e-12);
        // every win is +1.5R and every loss -1R, so the total is bounded by those plus timeouts
        assertTrue(bt.sumR >= -bt.losses - bt.timeouts * 3.0 - 1e-9);
        assertTrue(bt.sumR <= bt.wins * SignalEngine.TP1_R + bt.timeouts * 3.0 + 1e-9);
    }

    @Test
    public void backtestRespectsTheBarLimit() {
        Series s = new Series(TestData.pullbackTrend(900, 0.25, 3.0, 6.0));
        SignalEngine.Backtest part = SignalEngine.backtest(s, 400, 48);
        SignalEngine.Backtest all = SignalEngine.backtest(s, s.n, 48);
        assertTrue(part.trades <= all.trades);
        assertEquals(0, SignalEngine.backtest(s, 10, 48).trades);
    }

    @Test
    public void backtestStopsPessimisticallyWhenBothLevelsTouched() {
        // Hand-built: after a BUY entry, the next bar spans both SL and TP1; the replay must count a loss.
        Series s = new Series(TestData.pullbackTrend(700, 0.25, 3.0, 6.0));
        int entryBar = -1;
        Analysis entry = null;
        for (int i = SignalEngine.MIN_BARS - 1; i < s.n - 2; i++) {
            Analysis a = SignalEngine.evaluate(s, i, s.c[i]);
            if (a.signal == Analysis.Signal.BUY) { entryBar = i; entry = a; break; }
        }
        assertTrue(entryBar > 0);
        List<Candle> list = new java.util.ArrayList<>();
        for (int i = 0; i <= entryBar; i++) list.add(new Candle(s.t[i], s.o[i], s.h[i], s.l[i], s.c[i]));
        list.add(new Candle(s.t[entryBar] + 3_600_000L, entry.entry, entry.tp1 + 1, entry.sl - 1, entry.entry));
        list.add(new Candle(s.t[entryBar] + 7_200_000L, entry.entry, entry.entry + 0.1, entry.entry - 0.1, entry.entry));
        Series crafted = new Series(list);
        SignalEngine.Backtest bt = SignalEngine.backtest(crafted, crafted.n, 48);
        assertTrue(bt.losses >= 1);
    }
}
