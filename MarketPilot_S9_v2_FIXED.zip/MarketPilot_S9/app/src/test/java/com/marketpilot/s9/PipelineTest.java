package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

public class PipelineTest {
    private static final long NOW = 1_790_865_600_000L; // 2026-10-01 14:40 UTC

    @Test
    public void demoDataIsValidDeterministicAndVariesBySelection() {
        for (Instrument in : Instrument.values()) {
            for (Timeframe tf : Timeframe.values()) {
                List<Candle> a = DemoData.generate(in, tf, 1000, NOW);
                List<Candle> b = DemoData.generate(in, tf, 1000, NOW);
                assertEquals(1000, a.size());
                for (int i = 0; i < a.size(); i++) {
                    Candle c = a.get(i);
                    assertEquals(c.close, b.get(i).close, 0);
                    assertTrue(c.low > 0 && c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close));
                    if (i > 0) {
                        assertEquals(tf.ms, c.time - a.get(i - 1).time);
                        assertEquals(a.get(i - 1).close, c.open, 1e-12);
                    }
                }
                assertTrue(a.get(999).time <= NOW && NOW - a.get(999).time < tf.ms);
            }
        }
        assertTrue(DemoData.generate(Instrument.EURUSD, Timeframe.H1, 50, NOW).get(49).close
                != DemoData.generate(Instrument.GBPUSD, Timeframe.H1, 50, NOW).get(49).close);
    }

    @Test
    public void everySymbolAndTimeframeRunsEndToEnd() {
        for (Instrument in : Instrument.values()) {
            for (Timeframe tf : Timeframe.values()) {
                for (boolean closed : new boolean[]{true, false}) {
                    Pipeline.Result r = Pipeline.run(DemoData.generate(in, tf, 1000, NOW), in, tf, true, closed, NOW, NOW);
                    assertFalse(r.analysis.insufficient);
                    assertTrue(r.simulated);
                    assertTrue(r.text.headline.length() > 0);
                    assertTrue(r.text.meta.length() > 0);
                    assertEquals(r.analysis.trend + r.analysis.momentum + r.analysis.volatility + r.analysis.structure, r.analysis.score);
                    assertTrue(r.forming);
                    assertEquals(closed ? 998 : 999, r.evalIdx);
                    assertTrue(r.text.notes.size() >= 1 && r.text.notes.get(0).contains("candle"));
                }
            }
        }
    }

    @Test
    public void closedOnlyModeIgnoresTheFormingCandle() {
        List<Candle> base = DemoData.generate(Instrument.EURUSD, Timeframe.H1, 600, NOW);
        // Wreck the forming candle: closed-only analysis must not change.
        List<Candle> wrecked = new java.util.ArrayList<>(base.subList(0, 599));
        Candle last = base.get(599);
        wrecked.add(new Candle(last.time, last.open, last.open * 1.2, last.open * 0.8, last.open * 1.19));
        Pipeline.Result a = Pipeline.run(base, Instrument.EURUSD, Timeframe.H1, true, true, NOW, NOW);
        Pipeline.Result b = Pipeline.run(wrecked, Instrument.EURUSD, Timeframe.H1, true, true, NOW, NOW);
        assertEquals(a.analysis.score, b.analysis.score);
        assertEquals(a.analysis.signal, b.analysis.signal);
        assertEquals(a.analysis.rsi, b.analysis.rsi, 1e-12);
    }

    @Test
    public void staleDataIsDetectedAndOldBarsAreNotForming() {
        List<Candle> old = DemoData.generate(Instrument.EURUSD, Timeframe.H1, 300, NOW - 5 * 86_400_000L);
        Pipeline.Result r = Pipeline.run(old, Instrument.EURUSD, Timeframe.H1, false, true, NOW, NOW);
        assertTrue(r.stale);
        assertFalse(r.forming);
        assertEquals(299, r.evalIdx);
    }

    @Test
    public void emptyAndShortInputAreSafe() {
        Pipeline.Result e = Pipeline.run(new java.util.ArrayList<Candle>(), Instrument.EURUSD, Timeframe.H1, false, true, NOW, NOW);
        assertTrue(e.analysis.insufficient);
        assertEquals(0, e.backtest.trades);
        Pipeline.Result s = Pipeline.run(DemoData.generate(Instrument.XAUUSD, Timeframe.D1, 30, NOW), Instrument.XAUUSD, Timeframe.D1, false, true, NOW, NOW);
        assertTrue(s.analysis.insufficient);
        assertTrue(s.text.notes.size() > 0);
    }

    @Test
    public void fewerThan200CandlesDisablesEma200InsteadOfFaking() {
        Pipeline.Result r = Pipeline.run(DemoData.generate(Instrument.EURUSD, Timeframe.H1, 150, NOW), Instrument.EURUSD, Timeframe.H1, false, true, NOW, NOW);
        assertFalse(r.analysis.insufficient);
        assertFalse(r.analysis.hasEma200);
        assertTrue(Math.abs(r.analysis.trend) <= 2);
        boolean noted = false;
        for (String n : r.text.notes) if (n.contains("EMA200")) noted = true;
        assertTrue(noted);
    }

    @Test
    public void waitExplainsItself() {
        for (Instrument in : Instrument.values()) {
            for (Timeframe tf : Timeframe.values()) {
                Pipeline.Result r = Pipeline.run(DemoData.generate(in, tf, 1000, NOW), in, tf, true, true, NOW, NOW);
                if (r.analysis.isTrade()) continue;
                boolean explained = false;
                for (String n : r.text.notes) if (n.contains("WAIT") || n.contains("blocked")) explained = true;
                assertTrue(in + " " + tf + " WAIT must say why", explained);
            }
        }
    }
}
