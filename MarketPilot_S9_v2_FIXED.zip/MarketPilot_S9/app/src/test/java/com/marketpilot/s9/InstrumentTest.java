package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class InstrumentTest {
    @Test
    public void formatsWithMarketPrecision() {
        assertEquals("1.08350", Instrument.EURUSD.format(1.0835));
        assertEquals("147.250", Instrument.USDJPY.format(147.25));
        assertEquals("2650.00", Instrument.XAUUSD.format(2650));
        assertEquals("31.000", Instrument.XAGUSD.format(31));
        assertEquals("—", Instrument.EURUSD.format(Double.NaN));
    }

    @Test
    public void distancesAreInPipsForFxAndDollarsForMetals() {
        assertEquals("23.0 pips", Instrument.EURUSD.formatDistance(0.0023));
        assertEquals("50.0 pips", Instrument.USDJPY.formatDistance(0.5));
        assertEquals("$12.40", Instrument.XAUUSD.formatDistance(-12.4));
    }

    @Test
    public void lookupsAreClamped() {
        assertEquals(Instrument.EURUSD, Instrument.at(-5));
        assertEquals(Instrument.XAGUSD, Instrument.at(99));
        assertEquals(Timeframe.M15, Timeframe.at(-1));
        assertEquals(Timeframe.D1, Timeframe.at(42));
        assertEquals(Instrument.values().length, Instrument.labels().length);
    }
}
