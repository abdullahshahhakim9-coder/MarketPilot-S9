package com.marketpilot.s9;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Helpers that build deterministic candle series for tests. */
final class TestData {
    private TestData() {}

    static final long T0 = 1_700_000_000_000L;

    /** Candles from closes with wicks proportional to {@code wick}. */
    static List<Candle> fromCloses(double[] closes, double wick, long stepMs) {
        ArrayList<Candle> out = new ArrayList<>();
        for (int i = 0; i < closes.length; i++) {
            double o = i == 0 ? closes[0] : closes[i - 1];
            double c = closes[i];
            out.add(new Candle(T0 + i * stepMs, o, Math.max(o, c) + wick, Math.min(o, c) - wick, c));
        }
        return out;
    }

    /** Random walk with optional drift, around 100. */
    static List<Candle> randomWalk(long seed, int n, double drift, double vol) {
        Random r = new Random(seed);
        double[] c = new double[n];
        double p = 100;
        for (int i = 0; i < n; i++) {
            p += drift + vol * r.nextGaussian();
            c[i] = p;
        }
        ArrayList<Candle> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double o = i == 0 ? c[0] : c[i - 1];
            double hi = Math.max(o, c[i]) + Math.abs(r.nextGaussian()) * vol * 0.5;
            double lo = Math.min(o, c[i]) - Math.abs(r.nextGaussian()) * vol * 0.5;
            out.add(new Candle(T0 + i * 3_600_000L, o, hi, lo, c[i]));
        }
        return out;
    }

    /** Reflect prices around K: a bull market becomes the exact bear mirror image. */
    static List<Candle> mirror(List<Candle> in, double k) {
        ArrayList<Candle> out = new ArrayList<>();
        for (Candle c : in) out.add(new Candle(c.time, k - c.open, k - c.low, k - c.high, k - c.close));
        return out;
    }

    /** Rising market with regular pullbacks. */
    static List<Candle> pullbackTrend(int n, double slope, double amp, double period) {
        double[] c = new double[n];
        for (int i = 0; i < n; i++) c[i] = 100 + slope * i + amp * Math.sin(i / period);
        return fromCloses(c, 0.15, 3_600_000L);
    }
}
