package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RiskCalculatorTest {
    @Test
    public void eurusdFiftyPipStopOnOnePercentOfTenThousand() {
        // $100 risk / (0.0050 * 100,000) = 0.20 lots
        assertEquals(0.20, RiskCalculator.lots(Instrument.EURUSD, 10_000, 1.0, 1.1000, 1.0950), 1e-9);
    }

    @Test
    public void shortTradesUseAbsoluteDistance() {
        assertEquals(0.20, RiskCalculator.lots(Instrument.EURUSD, 10_000, 1.0, 1.0950, 1.1000), 1e-9);
    }

    @Test
    public void usdJpyConvertsYenPnlToDollars() {
        // $100 / (0.5 * 100,000 / 150) = 0.30 lots
        assertEquals(0.30, RiskCalculator.lots(Instrument.USDJPY, 10_000, 1.0, 150.0, 149.5), 1e-9);
    }

    @Test
    public void goldAndSilverUseOunceContracts() {
        assertEquals(0.05, RiskCalculator.lots(Instrument.XAUUSD, 10_000, 1.0, 2650, 2630), 1e-9);
        assertEquals(0.04, RiskCalculator.lots(Instrument.XAGUSD, 10_000, 1.0, 31.0, 30.5), 1e-9);
    }

    @Test
    public void roundsDownAndRejectsInvalidInput() {
        assertEquals(0.0, RiskCalculator.lots(Instrument.EURUSD, 10_000, 1.0, 1.1, 1.1), 0);
        assertEquals(0.0, RiskCalculator.lots(Instrument.EURUSD, 0, 1.0, 1.1, 1.09), 0);
        assertEquals(0.0, RiskCalculator.lots(Instrument.EURUSD, 10_000, 0, 1.1, 1.09), 0);
        // 0.2999 lots must floor to 0.29, never round up into extra risk
        assertEquals(0.29, RiskCalculator.lots(Instrument.EURUSD, 10_000, 1.0, 1.1000, 1.096666), 1e-9);
    }

    @Test
    public void lossAtStopNeverExceedsBudget() {
        double lots = RiskCalculator.lots(Instrument.XAUUSD, 5_000, 2.0, 2650, 2631.7);
        double loss = RiskCalculator.lossAtStop(Instrument.XAUUSD, lots, 2650, 2631.7);
        assertEquals(true, loss <= 100.0 + 1e-9);
    }
}
