package com.marketpilot.s9;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;

public class MarketDataClientTest {
    private static final String KEY = "SECRET123KEY";

    private static final String OK = "{\"meta\":{\"symbol\":\"EUR/USD\",\"interval\":\"1h\"},\"values\":["
            + "{\"datetime\":\"2026-10-01 14:00:00\",\"open\":\"1.08400\",\"high\":\"1.08500\",\"low\":\"1.08300\",\"close\":\"1.08450\"},"
            + "{\"datetime\":\"2026-10-01 13:00:00\",\"open\":\"1.08300\",\"high\":\"1.08450\",\"low\":\"1.08250\",\"close\":\"1.08400\"},"
            + "{\"datetime\":\"2026-10-01 12:00:00\",\"open\":\"1.08200\",\"high\":\"1.08350\",\"low\":\"1.08150\",\"close\":\"1.08300\"}"
            + "],\"status\":\"ok\"}";

    @Test
    public void parsesNewestFirstPayloadIntoOldestFirstCandles() throws Exception {
        List<Candle> c = MarketDataClient.parse(OK, KEY);
        assertEquals(3, c.size());
        assertTrue(c.get(0).time < c.get(1).time && c.get(1).time < c.get(2).time);
        assertEquals(1.083, c.get(0).close, 1e-12);
        assertEquals(1.0845, c.get(2).close, 1e-12);
        assertEquals(1.085, c.get(2).high, 1e-12);
        assertEquals(3_600_000L, c.get(1).time - c.get(0).time);
    }

    @Test
    public void parsesDateOnlyDailyBars() throws Exception {
        String body = "{\"values\":[{\"datetime\":\"2026-10-01\",\"open\":\"2\",\"high\":\"3\",\"low\":\"1\",\"close\":\"2.5\"},"
                + "{\"datetime\":\"2026-09-30\",\"open\":\"1\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"2\"}],\"status\":\"ok\"}";
        List<Candle> c = MarketDataClient.parse(body, KEY);
        assertEquals(2, c.size());
        assertEquals(86_400_000L, c.get(1).time - c.get(0).time);
    }

    @Test
    public void timestampsAreUtc() {
        assertEquals(0L, MarketDataClient.parseTime("garbage"));
        assertEquals(1_700_000_000_000L, MarketDataClient.parseTime("2023-11-14 22:13:20"));
    }

    @Test
    public void skipsBadRowsAndDuplicates() throws Exception {
        String body = "{\"values\":["
                + "{\"datetime\":\"2026-10-01 14:00:00\",\"open\":\"1\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"1.5\"},"
                + "{\"datetime\":\"2026-10-01 14:00:00\",\"open\":\"1\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"1.5\"},"
                + "{\"datetime\":\"2026-10-01 13:00:00\",\"open\":\"abc\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"1.5\"},"
                + "{\"datetime\":\"2026-10-01 12:00:00\",\"open\":\"1\",\"high\":\"0.1\",\"low\":\"0.5\",\"close\":\"1.5\"},"
                + "{\"datetime\":\"2026-10-01 11:00:00\",\"open\":\"-1\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"1.5\"},"
                + "{\"datetime\":\"2026-10-01 10:00:00\",\"open\":\"1\",\"high\":\"2\",\"low\":\"0.5\",\"close\":\"1.2\"}"
                + "],\"status\":\"ok\"}";
        List<Candle> c = MarketDataClient.parse(body, KEY);
        assertEquals(2, c.size());
        assertEquals(1.2, c.get(0).close, 1e-12);
    }

    @Test
    public void authErrorIsClassifiedAndNeverLeaksTheKey() {
        String body = "{\"code\":401,\"message\":\"apikey " + KEY + " is invalid\",\"status\":\"error\"}";
        try {
            MarketDataClient.parse(body, KEY);
            fail("expected exception");
        } catch (MarketDataClient.DataException e) {
            assertEquals(MarketDataClient.DataException.Kind.AUTH, e.kind);
            assertTrue(!e.getMessage().contains(KEY));
        }
    }

    @Test
    public void rateLimitIsClassified() {
        String body = "{\"code\":429,\"message\":\"You have run out of API credits for the current minute.\",\"status\":\"error\"}";
        try {
            MarketDataClient.parse(body, KEY);
            fail("expected exception");
        } catch (MarketDataClient.DataException e) {
            assertEquals(MarketDataClient.DataException.Kind.RATE_LIMIT, e.kind);
        }
    }

    @Test
    public void otherApiErrorsPassTheProviderMessageWithKeyRedacted() {
        String body = "{\"code\":400,\"message\":\"symbol not found for " + KEY + "\",\"status\":\"error\"}";
        try {
            MarketDataClient.parse(body, KEY);
            fail("expected exception");
        } catch (MarketDataClient.DataException e) {
            assertEquals(MarketDataClient.DataException.Kind.DATA, e.kind);
            assertTrue(e.getMessage().contains("symbol not found"));
            assertTrue(!e.getMessage().contains(KEY));
        }
    }

    @Test
    public void garbageEmptyAndMissingValuesAreDataErrors() {
        String[] bodies = {"", "<html>502</html>", "[]", "{}", "{\"values\":[]}", "{\"status\":\"ok\"}"};
        for (String b : bodies) {
            try {
                MarketDataClient.parse(b, KEY);
                fail("expected exception for: " + b);
            } catch (MarketDataClient.DataException e) {
                assertEquals(MarketDataClient.DataException.Kind.DATA, e.kind);
            }
        }
    }

    @Test
    public void nullBodyIsHandled() {
        try {
            MarketDataClient.parse(null, KEY);
            fail("expected exception");
        } catch (MarketDataClient.DataException e) {
            assertEquals(MarketDataClient.DataException.Kind.DATA, e.kind);
        }
    }

    @Test
    public void redactTruncatesAndHidesKey() {
        assertEquals("a •••", MarketDataClient.redact("a " + KEY, KEY));
        assertTrue(MarketDataClient.redact(new String(new char[500]).replace('\0', 'x'), KEY).length() <= 201);
    }
}
