@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "DIST_NAME=gradle-%GRADLE_VERSION%-bin.zip"
set "DIST_URL=https://services.gradle.org/distributions/%DIST_NAME%"
if defined GRADLE_USER_HOME (
  set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\marketpilot-%GRADLE_VERSION%"
) else (
  set "CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\marketpilot-%GRADLE_VERSION%"
)
set "DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP_PATH=%CACHE_DIR%\%DIST_NAME%"
set "PART_PATH=%ZIP_PATH%.part"
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
if not exist "%DIST_DIR%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  if exist "%PART_PATH%" del /q "%PART_PATH%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri '%DIST_URL%' -OutFile '%PART_PATH%'"
  if errorlevel 1 (
    echo Error: download failed. Check your connection and retry.
    if exist "%PART_PATH%" del /q "%PART_PATH%"
    exit /b 1
  )
  move /y "%PART_PATH%" "%ZIP_PATH%" >nul
  if exist "%CACHE_DIR%\unpack" rmdir /s /q "%CACHE_DIR%\unpack"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Expand-Archive -Force '%ZIP_PATH%' '%CACHE_DIR%\unpack'"
  if errorlevel 1 (
    echo Error: could not unpack Gradle. Deleting the archive so the next run downloads it again.
    del /q "%ZIP_PATH%"
    exit /b 1
  )
  move "%CACHE_DIR%\unpack\gradle-%GRADLE_VERSION%" "%DIST_DIR%" >nul
  rmdir /s /q "%CACHE_DIR%\unpack" 2>nul
)
call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
