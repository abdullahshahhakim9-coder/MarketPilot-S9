# MarketPilot S9 build configuration

Native Android Java application, no third-party runtime dependencies.

- Application ID: com.marketpilot.s9 (version 2.0.0, code 2)
- Compile SDK: 35 / Target SDK: 35 / Minimum SDK: 26
- Java: 17 (UTF-8 sources)
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (bootstrapped by `./gradlew`, version read from `gradle/wrapper/gradle-wrapper.properties`)
- Build: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
- Tests: `./gradlew testDebugUnitTest` (JUnit 4.13.2, org.json 20240303 — test scope only)

Notes
- `gradle-wrapper.jar` is intentionally absent; `gradlew` / `gradlew.bat` download and verify Gradle themselves.
- Backups are disabled (`allowBackup=false`); the API key is Keystore-encrypted.
- Targeting API 35 makes Android 15+ draw edge-to-edge; the app pads for system bars on those versions.
